const { getPool } = require('./backend/config/db');

async function probar() {
  try {
    const pool = await getPool();
    console.log('✅ Conexión exitosa');
    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

probar();