const sql = require('mssql');

const config = {
  server: 'localhost',
  database: 'SISTEMA_TUTORIAS',
  user: 'sa',
  password: 'francia',
  options: {
    trustedConnection: false,
    trustServerCertificate: true,
    enableArithAbort: true,
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let pool = null;

async function getPool() {
  if (!pool) {
    pool = await sql.connect(config);
  }
  return pool;
}

module.exports = { getPool, sql };