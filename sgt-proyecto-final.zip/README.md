# SGT — Sistema de Gestión de Tutorías
## TecNM Campus Culiacán

---

## 📁 Estructura del proyecto

```
sgt-completo/
├── backend/
│   ├── controllers/
│   │   ├── actividades.controller.js    ← NUEVO (Corrección 5)
│   │   ├── asignaciones.controller.js   ← Corregido (Corrección 1)
│   │   └── sesiones.controller.js       ← Corregido (Correcciones 3 y 4)
│   ├── middlewares/
│   │   └── upload.js                    ← Corregido (Corrección 2 — solo PDF)
│   └── routes/
│       ├── actividades.routes.js        ← NUEVO
│       ├── asignaciones.routes.js       ← Corregido
│       ├── sesiones.routes.js           ← Corregido
│       └── index.js                     ← Actualizado (incluye /actividades)
├── frontend/
│   └── sgt-frontend.html               ← Frontend completo
└── sql/
    └── migracion_correcciones.sql       ← Ejecutar una sola vez en la BD
```

---

## 🚀 Instrucciones de instalación

### 1. Base de datos
Ejecuta el script SQL **una sola vez** sobre tu base de datos existente:
```
sql/migracion_correcciones.sql
```
Esto agrega:
- Columna `tutorAsistio` en tabla `Sesion`
- Columna `fechaLimiteEntrega` en tabla `Sesion`
- Tabla `FaltaTutor` (registro de faltas del tutor)
- Tabla `Actividad` (actividades asignadas por coordinador)

### 2. Backend
Copia los archivos a tu proyecto según la estructura:

| Archivo | Destino en tu proyecto |
|---------|------------------------|
| `backend/controllers/*.js` | `src/controllers/` |
| `backend/middlewares/upload.js` | `src/middlewares/upload.js` |
| `backend/routes/*.js` | `src/routes/` |

### 3. Frontend
Abre `frontend/sgt-frontend.html` y edita la línea 1 del script:
```javascript
const API = 'http://localhost:3000/api'; // ← cambia por tu URL
```
Luego abre el archivo en cualquier navegador.

---

## ✅ Correcciones implementadas

| # | Corrección | Archivos afectados |
|---|------------|--------------------|
| 1 | Asignación de tutores a tutorados con validaciones completas | `asignaciones.controller.js`, `asignaciones.routes.js` |
| 2 | Solo PDF en evaluación de evidencias | `upload.js` |
| 3 | Falta automática al tutor si no asistió | `sesiones.controller.js`, `sesiones.routes.js` |
| 4 | Validar fecha límite de entrega ≤ fecha actual | `sesiones.controller.js`, `sesiones.routes.js` |
| 5 | Tutor puede modificar actividades asignadas por coordinador | `actividades.controller.js` (nuevo), `actividades.routes.js` (nuevo) |

---

## 🌐 Endpoints nuevos

```
GET  /api/asignaciones/disponibles?idPrograma=X  → Tutorados sin asignación activa
GET  /api/actividades                             → Listar actividades
POST /api/actividades                             → Crear (coordinador/admin)
PATCH /api/actividades/:id/tutor                  → Modificar como tutor
PUT  /api/actividades/:id                         → Editar completo (coordinador)
DELETE /api/actividades/:id                       → Eliminar (coordinador/admin)
```

---

## 🎨 Frontend — Módulos incluidos

- **Login** con validación de correo @culiacan.tecnm.mx
- **Dashboard** con estadísticas en tiempo real
- **Usuarios, Tutores, Tutorados** — CRUD completo
- **Asignaciones** — con lista de tutorados disponibles
- **Sesiones** — con asistencia y falta del tutor
- **Evidencias** — solo PDF, subida multipart
- **Evaluaciones** — 7 criterios, validación
- **Canalizaciones** — CRUD con estatus
- **Actividades** — diferenciado por rol (tutor vs coordinador)
- **Informes** — CRUD con estados
- **Reportes** — 4 reportes dinámicos

---

## 🔐 Roles del sistema

| Rol | Acceso |
|-----|--------|
| Administrador | Todo el sistema |
| Coordinadora Institucional | Programas, tutores, tutorados, asignaciones, actividades, reportes |
| Coordinadora Departamental | Tutores, tutorados, asignaciones, sesiones, canalizaciones, reportes |
| Tutor | Sus tutorados, sesiones, evidencias, evaluaciones, actividades (edición limitada), informes |
| Tutorado | Sus evidencias y sesiones |
