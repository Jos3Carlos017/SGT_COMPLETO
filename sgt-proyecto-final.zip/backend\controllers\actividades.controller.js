/**
 * Controlador de actividades del programa de tutorías.
 * CORRECCIÓN 5: El tutor puede modificar (adaptar) las actividades que le asignó
 *               el coordinador institucional, sin poder eliminarlas ni cambiar
 *               el tipo/categoría original.
 * @module controllers/actividades
 */
const { getPool, sql } = require('../config/db');

/** GET /api/actividades — Listar todas las actividades */
const getAll = async (req, res, next) => {
  try {
    const { idPrograma, noEmpleado } = req.query;
    const pool    = await getPool();
    const request = pool.request();
    let   query   = `
      SELECT A.idActividad, A.idPrograma, P.cicloEscolar,
             A.titulo, A.descripcion, A.tipoActividad, A.fechaLimite,
             A.creadaPor, UC.nombre AS nombreCoordinador, UC.rol AS rolCreador,
             A.modificadaPor, UT.nombre AS nombreTutorModificador,
             A.notasTutor, A.fechaModificacion, A.estado
      FROM   Actividad A
      INNER JOIN Programa_Tutorias P ON P.idPrograma = A.idPrograma
      INNER JOIN Usuario UC ON UC.idUsuario = A.creadaPor
      LEFT  JOIN Usuario UT ON UT.idUsuario = A.modificadaPor
      WHERE  1=1`;
    if (idPrograma)  { request.input('idPrograma',  sql.Int,        idPrograma);  query += ' AND A.idPrograma = @idPrograma'; }
    if (noEmpleado)  { request.input('noEmpleado',  sql.VarChar(20), noEmpleado); query += ' AND A.idPrograma IN (SELECT idPrograma FROM Asignacion WHERE noEmpleado = @noEmpleado)'; }
    const result = await request.query(query + ' ORDER BY A.fechaLimite ASC');
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

/** GET /api/actividades/:id */
const getById = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`
        SELECT A.*, UC.nombre AS nombreCoordinador, UT.nombre AS nombreTutorModificador
        FROM   Actividad A
        INNER JOIN Usuario UC ON UC.idUsuario = A.creadaPor
        LEFT  JOIN Usuario UT ON UT.idUsuario = A.modificadaPor
        WHERE  A.idActividad = @id`);
    if (!result.recordset[0])
      return res.status(404).json({ success: false, message: 'Actividad no encontrada.' });
    return res.status(200).json({ success: true, data: result.recordset[0] });
  } catch (err) { next(err); }
};

/** POST /api/actividades — Solo coordinador institucional puede crear */
const create = async (req, res, next) => {
  try {
    const { idPrograma, titulo, descripcion, tipoActividad, fechaLimite } = req.body;
    const pool   = await getPool();

    // Verificar que el programa exista y esté activo
    const prog = await pool.request()
      .input('idPrograma', sql.Int, idPrograma)
      .query(`SELECT estado FROM Programa_Tutorias WHERE idPrograma = @idPrograma`);
    if (!prog.recordset[0])
      return res.status(404).json({ success: false, message: 'Programa no encontrado.' });
    if (prog.recordset[0].estado !== 'Activo')
      return res.status(400).json({ success: false, message: 'Solo se pueden agregar actividades a un programa activo.' });

    const result = await pool.request()
      .input('idPrograma',   sql.Int,              idPrograma)
      .input('titulo',       sql.NVarChar(200),    titulo)
      .input('descripcion',  sql.NVarChar(sql.MAX), descripcion || null)
      .input('tipoActividad',sql.VarChar(50),      tipoActividad)
      .input('fechaLimite',  sql.Date,             fechaLimite || null)
      .input('creadaPor',    sql.Int,              req.usuario.idUsuario)
      .query(`INSERT INTO Actividad (idPrograma, titulo, descripcion, tipoActividad, fechaLimite, creadaPor, estado)
              VALUES (@idPrograma, @titulo, @descripcion, @tipoActividad, @fechaLimite, @creadaPor, 'Pendiente');
              SELECT SCOPE_IDENTITY() AS idActividad;`);

    const idActividad = result.recordset[0]?.idActividad;

    // Si el creador es un Tutor, auto-habilitar la actividad para sus tutorados
    if (req.usuario.rol === 'Tutor' && idActividad) {
      const tutorRec = await pool.request()
        .input('uid', sql.Int, req.usuario.idUsuario)
        .query('SELECT noEmpleado FROM Tutor WHERE idUsuario = @uid');
      const noEmpleado = tutorRec.recordset[0]?.noEmpleado;
      if (noEmpleado) {
        await pool.request()
          .input('idAct', sql.Int,         idActividad)
          .input('noEmp', sql.NVarChar(20), noEmpleado)
          .query(`INSERT INTO ActividadTutorHabilitada(idActividad,noEmpleado,habilitada)
                  VALUES(@idAct,@noEmp,1)`);
      }
    }

    return res.status(201).json({
      success: true,
      message: 'Actividad creada y asignada al programa.',
      data: { idActividad: result.recordset[0].idActividad },
    });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// CORRECCIÓN 5: El tutor puede modificar descripción, notas y estado de la
//               actividad, pero NO puede cambiar titulo ni tipoActividad
//               (esos son exclusivos del coordinador).
// ─────────────────────────────────────────────────────────────────────────────
const updateByTutor = async (req, res, next) => {
  try {
    const { descripcion, notasTutor, estado } = req.body;
    const pool = await getPool();

    // Verificar que la actividad existe
    const check = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`SELECT A.idActividad, A.estado, A.idPrograma
              FROM Actividad A WHERE A.idActividad = @id`);
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Actividad no encontrada.' });

    // Verificar que el tutor tiene asignación en el programa de esa actividad
    const noEmpleado = req.usuario.numEmpleado || req.body.noEmpleado;
    if (!noEmpleado)
      return res.status(400).json({ success: false, message: 'noEmpleado requerido.' });

    const asig = await pool.request()
      .input('idPrograma', sql.Int,        check.recordset[0].idPrograma)
      .input('noEmp',      sql.VarChar(20), noEmpleado)
      .query(`SELECT idAsignacion FROM Asignacion
              WHERE idPrograma = @idPrograma AND noEmpleado = @noEmp AND estado = 'Activa'`);
    if (!asig.recordset[0])
      return res.status(403).json({ success: false, message: 'No tienes una asignación activa en el programa de esta actividad.' });

    // Validar estado permitido para el tutor
    const estadosPermitidos = ['En Proceso', 'Completada'];
    if (estado && !estadosPermitidos.includes(estado))
      return res.status(400).json({ success: false, message: `Estado inválido. El tutor solo puede usar: ${estadosPermitidos.join(', ')}.` });

    await pool.request()
      .input('id',              sql.Int,              req.params.id)
      .input('descripcion',     sql.NVarChar(sql.MAX), descripcion  || null)
      .input('notasTutor',      sql.NVarChar(sql.MAX), notasTutor   || null)
      .input('estado',          sql.VarChar(30),      estado        || null)
      .input('modificadaPor',   sql.Int,              req.usuario.idUsuario)
      .query(`UPDATE Actividad SET
                descripcion     = COALESCE(@descripcion,   descripcion),
                notasTutor      = COALESCE(@notasTutor,    notasTutor),
                estado          = COALESCE(@estado,        estado),
                modificadaPor   = @modificadaPor,
                fechaModificacion = GETDATE()
              WHERE idActividad = @id`);

    return res.status(200).json({ success: true, message: 'Actividad actualizada por el tutor.' });
  } catch (err) { next(err); }
};

/** PUT /api/actividades/:id — Coordinador puede editar todo */
const updateByCoord = async (req, res, next) => {
  try {
    const { titulo, descripcion, tipoActividad, fechaLimite, estado } = req.body;
    const pool = await getPool();

    const check = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query('SELECT idActividad FROM Actividad WHERE idActividad = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Actividad no encontrada.' });

    await pool.request()
      .input('id',           sql.Int,              req.params.id)
      .input('titulo',       sql.NVarChar(200),    titulo        || null)
      .input('descripcion',  sql.NVarChar(sql.MAX), descripcion   || null)
      .input('tipoActividad',sql.VarChar(50),      tipoActividad || null)
      .input('fechaLimite',  sql.Date,             fechaLimite   || null)
      .input('estado',       sql.VarChar(30),      estado        || null)
      .query(`UPDATE Actividad SET
                titulo        = COALESCE(@titulo,        titulo),
                descripcion   = COALESCE(@descripcion,   descripcion),
                tipoActividad = COALESCE(@tipoActividad, tipoActividad),
                fechaLimite   = COALESCE(@fechaLimite,   fechaLimite),
                estado        = COALESCE(@estado,        estado)
              WHERE idActividad = @id`);

    return res.status(200).json({ success: true, message: 'Actividad actualizada por coordinador.' });
  } catch (err) { next(err); }
};

/** DELETE /api/actividades/:id — Solo coordinador/admin */
const remove = async (req, res, next) => {
  try {
    const pool  = await getPool();
    const check = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query('SELECT idActividad FROM Actividad WHERE idActividad = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Actividad no encontrada.' });
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query('DELETE FROM Actividad WHERE idActividad = @id');
    return res.status(200).json({ success: true, message: 'Actividad eliminada.' });
  } catch (err) { next(err); }
};

// Actividades creadas por un usuario específico
const getMisActividades = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('idUsuario', sql.Int, req.params.idUsuario)
      .query(`SELECT idActividad, titulo, tipoActividad, descripcion,
                     fechaLimite, estado, idPrograma, creadaPor, notasTutor
              FROM   Actividad
              WHERE  creadaPor = @idUsuario AND estado != 'Cancelada'
              ORDER  BY idActividad`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// Obtener actividades habilitadas por un tutor específico (para tutorados)
const getHabilitadasPorTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noEmp', sql.NVarChar(20), req.params.noEmp)
      .query(`
        SELECT A.idActividad, A.titulo, A.tipoActividad, A.descripcion,
               A.fechaLimite, A.estado, A.idPrograma, ATH.fechaHab
        FROM   Actividad A
        INNER  JOIN ActividadTutorHabilitada ATH
               ON ATH.idActividad = A.idActividad AND ATH.noEmpleado = @noEmp
        WHERE  ATH.habilitada = 1 AND A.estado != 'Cancelada'
        ORDER  BY A.idActividad`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// Toggle habilitar/deshabilitar actividad para tutorados del tutor
const toggleHabilitar = async (req, res, next) => {
  try {
    const { noEmpleado } = req.body;
    const idActividad = parseInt(req.params.id);
    const pool = await getPool();

    // Ver si ya existe el registro
    const existing = await pool.request()
      .input('idAct', sql.Int,         idActividad)
      .input('noEmp', sql.NVarChar(20), noEmpleado)
      .query(`SELECT idActHab, habilitada FROM ActividadTutorHabilitada
              WHERE idActividad=@idAct AND noEmpleado=@noEmp`);

    if (existing.recordset[0]) {
      // Toggle el estado actual
      const nuevoEstado = existing.recordset[0].habilitada ? 0 : 1;
      await pool.request()
        .input('idAct', sql.Int,         idActividad)
        .input('noEmp', sql.NVarChar(20), noEmpleado)
        .input('hab',   sql.Bit,          nuevoEstado)
        .query(`UPDATE ActividadTutorHabilitada SET habilitada=@hab, fechaHab=GETDATE()
                WHERE idActividad=@idAct AND noEmpleado=@noEmp`);
      return res.status(200).json({ success: true, habilitada: !!nuevoEstado,
        message: nuevoEstado ? 'Sesión habilitada para tus tutorados.' : 'Sesión deshabilitada.' });
    } else {
      // Crear como habilitada
      await pool.request()
        .input('idAct', sql.Int,         idActividad)
        .input('noEmp', sql.NVarChar(20), noEmpleado)
        .query(`INSERT INTO ActividadTutorHabilitada(idActividad,noEmpleado,habilitada)
                VALUES(@idAct,@noEmp,1)`);
      return res.status(201).json({ success: true, habilitada: true,
        message: 'Sesión habilitada para tus tutorados.' });
    }
  } catch (err) { next(err); }
};

module.exports = { getAll, getById, getMisActividades, create, updateByTutor, updateByCoord, remove, getHabilitadasPorTutor, toggleHabilitar };
