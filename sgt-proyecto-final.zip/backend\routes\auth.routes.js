const router = require('express').Router();
const { login, cambiarPassword, primerAcceso } = require('../controllers/auth.controller');

router.post('/login',            login);
router.post('/cambiar-password', cambiarPassword);
router.post('/primer-acceso',    primerAcceso);

module.exports = router;
