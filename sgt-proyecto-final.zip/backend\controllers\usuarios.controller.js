const bcrypt = require('bcryptjs');
const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(
      `SELECT idUsuario, nombre, correoInst, rol, estado, numEmpleado, numControl, departamento, carrera, created_at
       FROM Usuario ORDER BY nombre`
    );
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { nombre, correoInst, rol, numEmpleado, numControl, departamento, carrera, password } = req.body;
    const pool = await getPool();

    // Si se proporcionó contraseña, hashearla; si no, forzar cambio en primer login
    let hash = 'CAMBIAR_AL_PRIMER_LOGIN';
    if (password && password.length >= 6) {
      hash = await bcrypt.hash(password, 10);
    }

    // Crear usuario base
    const req2 = pool.request()
      .input('nombre',      sql.NVarChar(150), nombre)
      .input('correo',      sql.NVarChar(150), correoInst)
      .input('hash',        sql.NVarChar(255), hash)
      .input('rol',         sql.NVarChar(60),  rol)
      .input('numEmpleado', sql.NVarChar(20),  numEmpleado || null)
      .input('numControl',  sql.NVarChar(20),  numControl  || null)
      .input('depto',       sql.NVarChar(100), departamento || null)
      .input('carrera',     sql.NVarChar(100), carrera || null);

    // Usar SCOPE_IDENTITY() para evitar conflicto con trigger trg_ValidarCorreo
    const insertRes = await req2.query(`
      INSERT INTO Usuario(nombre,correoInst,passwordHash,rol,estado,numEmpleado,numControl,departamento,carrera)
      VALUES(@nombre,@correo,@hash,@rol,'Activo',@numEmpleado,@numControl,@depto,@carrera);
      SELECT SCOPE_IDENTITY() AS idUsuario;`);

    const idUsuario = insertRes.recordset[0]?.idUsuario;

    // Si es Tutor, crear automáticamente el registro en la tabla Tutor
    if (rol === 'Tutor' && numEmpleado && idUsuario) {
      await pool.request()
        .input('noEmpleado', sql.NVarChar(20), numEmpleado)
        .input('idUsuario',  sql.Int,          idUsuario)
        .query(`INSERT INTO Tutor(noEmpleado, tipoContrato, diplomado, cupoDisponible, idUsuario)
                VALUES(@noEmpleado, 'Tiempo Completo', 1, 25, @idUsuario)`);
    }

    // Si es Tutorado, crear automáticamente el registro en la tabla Tutorado
    if (rol === 'Tutorado' && numControl && idUsuario) {
      await pool.request()
        .input('noControl', sql.NVarChar(20),  numControl)
        .input('carrera2',  sql.NVarChar(100), carrera || 'Ing. Sistemas Computacionales')
        .input('idUsuario', sql.Int,           idUsuario)
        .query(`INSERT INTO Tutorado(noControl, carrera, semestre, estatus, idUsuario)
                VALUES(@noControl, @carrera2, 1, 'Activo', @idUsuario)`);
    }

    return res.status(201).json({ success: true, message: 'Usuario creado correctamente' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { nombre, rol, estado, departamento, carrera } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('id',      sql.Int,          req.params.id)
      .input('nombre',  sql.NVarChar(150), nombre  || null)
      .input('rol',     sql.NVarChar(60),  rol     || null)
      .input('estado',  sql.NVarChar(30),  estado  || null)
      .input('depto',   sql.NVarChar(100), departamento || null)
      .input('carrera', sql.NVarChar(100), carrera || null)
      .query(`UPDATE Usuario SET
                nombre      = COALESCE(@nombre,  nombre),
                rol         = COALESCE(@rol,     rol),
                estado      = COALESCE(@estado,  estado),
                departamento= COALESCE(@depto,   departamento),
                carrera     = COALESCE(@carrera, carrera),
                updated_at  = GETDATE()
              WHERE idUsuario=@id`);
    return res.status(200).json({ success: true, message: 'Usuario actualizado' });
  } catch (err) { next(err); }
};

const desactivar = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`UPDATE Usuario SET estado='Inactivo', updated_at=GETDATE() WHERE idUsuario=@id`);
    return res.status(200).json({ success: true, message: 'Usuario desactivado' });
  } catch (err) { next(err); }
};

const resetPassword = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`UPDATE Usuario SET passwordHash='CAMBIAR_AL_PRIMER_LOGIN', updated_at=GETDATE() WHERE idUsuario=@id`);
    return res.status(200).json({ success: true, message: 'Contraseña restablecida' });
  } catch (err) { next(err); }
};

module.exports = { getAll, create, update, desactivar, resetPassword };
