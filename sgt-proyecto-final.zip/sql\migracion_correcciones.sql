-- ═══════════════════════════════════════════════════════════════════════════
-- SCRIPT DE MIGRACIÓN — SGT Correcciones
-- Ejecutar UNA SOLA VEZ sobre la base de datos existente.
-- ═══════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- CORRECCIÓN 3 y 4: Agregar columnas tutorAsistio y fechaLimiteEntrega a Sesion
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'Sesion' AND COLUMN_NAME = 'tutorAsistio'
)
BEGIN
  ALTER TABLE Sesion ADD tutorAsistio BIT NOT NULL DEFAULT 1;
  PRINT 'Columna tutorAsistio agregada a Sesion.';
END

IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'Sesion' AND COLUMN_NAME = 'fechaLimiteEntrega'
)
BEGIN
  ALTER TABLE Sesion ADD fechaLimiteEntrega DATE NULL;
  PRINT 'Columna fechaLimiteEntrega agregada a Sesion.';
END

-- ─────────────────────────────────────────────────────────────────────────────
-- CORRECCIÓN 3: Tabla FaltaTutor para registrar ausencias del tutor
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'FaltaTutor'
)
BEGIN
  CREATE TABLE FaltaTutor (
    idFalta       INT           IDENTITY(1,1) PRIMARY KEY,
    noEmpleado    VARCHAR(20)   NOT NULL,
    idSesion      INT           NOT NULL,
    fechaRegistro DATETIME2     NOT NULL DEFAULT GETDATE(),
    observaciones NVARCHAR(500) NULL,
    CONSTRAINT FK_FaltaTutor_Tutor  FOREIGN KEY (noEmpleado) REFERENCES Tutor(noEmpleado),
    CONSTRAINT FK_FaltaTutor_Sesion FOREIGN KEY (idSesion)   REFERENCES Sesion(idSesion),
    CONSTRAINT UQ_FaltaTutor        UNIQUE (noEmpleado, idSesion)
  );
  PRINT 'Tabla FaltaTutor creada.';
END

-- ─────────────────────────────────────────────────────────────────────────────
-- CORRECCIÓN 5: Tabla Actividad para actividades asignadas por coordinador
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Actividad'
)
BEGIN
  CREATE TABLE Actividad (
    idActividad       INT            IDENTITY(1,1) PRIMARY KEY,
    idPrograma        INT            NOT NULL,
    titulo            NVARCHAR(200)  NOT NULL,
    descripcion       NVARCHAR(MAX)  NULL,
    tipoActividad     VARCHAR(50)    NOT NULL,
    fechaLimite       DATE           NULL,
    estado            VARCHAR(30)    NOT NULL DEFAULT 'Pendiente',
    -- Auditoría
    creadaPor         INT            NOT NULL,   -- idUsuario del coordinador
    modificadaPor     INT            NULL,        -- idUsuario del tutor que modificó
    notasTutor        NVARCHAR(MAX)  NULL,        -- notas que puede agregar el tutor
    fechaModificacion DATETIME2      NULL,
    created_at        DATETIME2      NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Actividad_Programa  FOREIGN KEY (idPrograma)    REFERENCES Programa_Tutorias(idPrograma),
    CONSTRAINT FK_Actividad_Creador   FOREIGN KEY (creadaPor)     REFERENCES Usuario(idUsuario),
    CONSTRAINT FK_Actividad_Modificar FOREIGN KEY (modificadaPor) REFERENCES Usuario(idUsuario),
    CONSTRAINT CK_Actividad_Estado    CHECK (estado IN ('Pendiente','En Proceso','Completada','Cancelada'))
  );
  PRINT 'Tabla Actividad creada.';
END

PRINT '✅ Migración completada correctamente.';
