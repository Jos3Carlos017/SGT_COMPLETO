const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/tutorados.controller');

router.get('/',               auth, ctrl.getAll);
router.get('/:noControl',     auth, ctrl.getOne);
router.post('/',              auth, ctrl.create);
router.put('/:noControl',     auth, ctrl.update);

module.exports = router;
