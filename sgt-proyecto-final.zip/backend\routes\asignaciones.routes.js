/**
 * Rutas de asignaciones (RF-ASI-01)
 * CORRECCIÓN 1: Asignación de tutores a tutorados con validaciones y endpoint extra.
 * @module routes/asignaciones
 */
const router                       = require('express').Router();
const { body, param, query }       = require('express-validator');
const validate                     = require('../middlewares/validate');
const { verifyToken, requireRole } = require('../middlewares/auth');
const ctrl                         = require('../controllers/asignaciones.controller');

router.use(verifyToken);

router.get('/',                         ctrl.getAll);
router.get('/tutor/:noEmp',             ctrl.getByTutor);
router.get('/tutorado/:noControl',      ctrl.getByTutorado);

// CORRECCIÓN 1: Tutorados sin asignación activa (para el formulario de asignación)
router.get('/disponibles',
  query('idPrograma').optional().isInt({ min: 1 }),
  validate,
  requireRole('Administrador','Coordinadora Departamental','Coordinadora Institucional','Jefe Departamento'),
  ctrl.getTutoradosDisponibles
);

router.get('/:id', param('id').isInt({ min: 1 }), validate, ctrl.getById);

router.post('/',
  [
    body('noEmpleado').notEmpty().withMessage('noEmpleado es requerido.'),
    body('noControl').notEmpty().withMessage('noControl es requerido.'),
    body('periodo').notEmpty().withMessage('El periodo es requerido.'),
    body('idPrograma').isInt({ min: 1 }).withMessage('idPrograma inválido.'),
  ],
  validate,
  requireRole('Administrador','Coordinadora Departamental','Jefe Departamento'),
  ctrl.create
);

router.put('/:id',
  param('id').isInt({ min: 1 }),
  validate,
  requireRole('Administrador','Coordinadora Departamental','Jefe Departamento'),
  ctrl.update
);

router.delete('/:id',
  param('id').isInt({ min: 1 }),
  validate,
  requireRole('Administrador','Jefe Departamento'),
  ctrl.remove
);

module.exports = router;
