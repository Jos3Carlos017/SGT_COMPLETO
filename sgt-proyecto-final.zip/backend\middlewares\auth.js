const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ success: false, message: 'Token requerido' });
  const token = header.split(' ')[1];
  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ success: false, message: 'Token inválido o expirado' });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!req.usuario) return res.status(401).json({ success: false, message: 'No autenticado' });
  if (!roles.includes(req.usuario.rol))
    return res.status(403).json({ success: false, message: `Acceso denegado. Se requiere rol: ${roles.join(' o ')}` });
  next();
};

module.exports = verifyToken;
module.exports.verifyToken = verifyToken;
module.exports.requireRole = requireRole;
