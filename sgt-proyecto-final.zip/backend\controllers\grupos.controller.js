const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT G.idGrupo, G.noEmpleado, U.nombre AS tutor,
             G.idPrograma, P.cicloEscolar,
             G.carrera, G.nombreGrupo, G.salon,
             G.dia, G.horaInicio, G.horaFin, G.estado
      FROM   GrupoTutor G
      INNER  JOIN Tutor T  ON T.noEmpleado = G.noEmpleado
      INNER  JOIN Usuario U ON U.idUsuario  = T.idUsuario
      INNER  JOIN Programa_Tutorias P ON P.idPrograma = G.idPrograma
      ORDER  BY U.nombre`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getByTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noEmp', sql.VarChar(20), req.params.noEmp)
      .query(`
        SELECT G.idGrupo, G.carrera, G.nombreGrupo, G.salon,
               G.dia, G.horaInicio, G.horaFin, G.estado,
               P.cicloEscolar
        FROM   GrupoTutor G
        INNER  JOIN Programa_Tutorias P ON P.idPrograma = G.idPrograma
        WHERE  G.noEmpleado = @noEmp AND G.estado = 'Activo'`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { noEmpleado, idPrograma, carrera, nombreGrupo, salon, dia, horaInicio, horaFin } = req.body;
    if (!noEmpleado || !idPrograma || !carrera || !salon || !dia || !horaInicio || !horaFin)
      return res.status(400).json({ success: false, message: 'Todos los campos son requeridos.' });

    const pool = await getPool();

    // Verificar si el tutor ya tiene grupo en este programa
    const existing = await pool.request()
      .input('noEmp',     sql.VarChar(20), noEmpleado)
      .input('idPrograma',sql.Int,         idPrograma)
      .query(`SELECT idGrupo FROM GrupoTutor WHERE noEmpleado=@noEmp AND idPrograma=@idPrograma`);
    if (existing.recordset[0])
      return res.status(409).json({ success: false, message: 'Este tutor ya tiene un grupo asignado en este programa. Elimina el anterior antes de crear uno nuevo.' });

    // Verificar conflicto de salón + día + hora
    const conflicto = await pool.request()
      .input('salon',     sql.VarChar(20), salon)
      .input('dia',       sql.VarChar(20), dia)
      .input('horaInicio',sql.VarChar(10), horaInicio)
      .input('idPrograma',sql.Int,         idPrograma)
      .input('noEmp',     sql.VarChar(20), noEmpleado)
      .query(`
        SELECT G.noEmpleado, U.nombre AS tutor
        FROM   GrupoTutor G
        INNER  JOIN Tutor T  ON T.noEmpleado = G.noEmpleado
        INNER  JOIN Usuario U ON U.idUsuario  = T.idUsuario
        WHERE  G.salon      = @salon
          AND  G.dia        = @dia
          AND  G.horaInicio = @horaInicio
          AND  G.idPrograma = @idPrograma
          AND  G.noEmpleado != @noEmp
          AND  G.estado     = 'Activo'`);
    if (conflicto.recordset[0])
      return res.status(409).json({
        success: false,
        message: `Conflicto: El salón "${salon}" el ${dia} a las ${horaInicio} ya está ocupado por el tutor "${conflicto.recordset[0].tutor}".`
      });

    await pool.request()
      .input('noEmpleado',  sql.NVarChar(20),  noEmpleado)
      .input('idPrograma',  sql.Int,           idPrograma)
      .input('carrera',     sql.NVarChar(100), carrera)
      .input('nombreGrupo', sql.NVarChar(50),  nombreGrupo || 'A')
      .input('salon',       sql.NVarChar(20),  salon)
      .input('dia',         sql.NVarChar(20),  dia)
      .input('horaInicio',  sql.NVarChar(10),  horaInicio)
      .input('horaFin',     sql.NVarChar(10),  horaFin)
      .query(`INSERT INTO GrupoTutor(noEmpleado,idPrograma,carrera,nombreGrupo,salon,dia,horaInicio,horaFin)
              VALUES(@noEmpleado,@idPrograma,@carrera,@nombreGrupo,@salon,@dia,@horaInicio,@horaFin)`);

    return res.status(201).json({ success: true, message: 'Grupo asignado correctamente.' });
  } catch (err) { next(err); }
};

const remove = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`DELETE FROM GrupoTutor WHERE idGrupo = @id`);
    return res.status(200).json({ success: true, message: 'Asignación de grupo eliminada.' });
  } catch (err) { next(err); }
};

module.exports = { getAll, getByTutor, create, remove };
