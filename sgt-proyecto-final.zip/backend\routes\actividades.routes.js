/**
 * Rutas de actividades del programa de tutorías.
 * CORRECCIÓN 5: El tutor puede modificar actividades que le asignó el coordinador.
 * @module routes/actividades
 */
const router                       = require('express').Router();
const { body, param, query }       = require('express-validator');
const validate                     = require('../middlewares/validate');
const { verifyToken, requireRole } = require('../middlewares/auth');
const ctrl                         = require('../controllers/actividades.controller');

router.use(verifyToken);

// ── Consultas ────────────────────────────────────────────────────────────────
router.get('/',
  [
    query('idPrograma').optional().isInt({ min: 1 }),
    query('noEmpleado').optional().notEmpty(),
  ],
  validate,
  ctrl.getAll
);

router.get('/:id',
  param('id').isInt({ min: 1 }),
  validate,
  ctrl.getById
);

// ── Actividades creadas por un usuario específico (tutor ve las suyas) ────────
router.get('/creadas-por/:idUsuario', ctrl.getMisActividades);

// ── Crear actividad (coordinador/admin/tutor) ─────────────────────────────────
router.post('/',
  [
    body('idPrograma').isInt({ min: 1 }).withMessage('idPrograma requerido.'),
    body('titulo').notEmpty().trim().withMessage('El título es requerido.'),
    body('tipoActividad').notEmpty().trim().withMessage('El tipo de actividad es requerido.'),
    body('descripcion').optional().trim(),
    body('fechaLimite').optional().isDate().withMessage('Fecha límite inválida.'),
  ],
  validate,
  requireRole('Coordinadora Institucional', 'Administrador', 'Tutor'),
  ctrl.create
);

// ── CORRECCIÓN 5: El tutor modifica descripción, notas y estado ──────────────
router.patch('/:id/tutor',
  [
    param('id').isInt({ min: 1 }),
    body('descripcion').optional().trim(),
    body('notasTutor').optional().trim(),
    body('estado').optional().isIn(['En Proceso', 'Completada'])
      .withMessage('El tutor solo puede marcar: En Proceso, Completada.'),
    body('noEmpleado').optional().notEmpty(),
  ],
  validate,
  requireRole('Tutor'),
  ctrl.updateByTutor
);

// ── Coordinador puede editar todo ────────────────────────────────────────────
router.put('/:id',
  [
    param('id').isInt({ min: 1 }),
    body('titulo').optional().notEmpty().trim(),
    body('descripcion').optional().trim(),
    body('tipoActividad').optional().notEmpty().trim(),
    body('fechaLimite').optional().isDate().withMessage('Fecha límite inválida.'),
    body('estado').optional().isIn(['Pendiente', 'En Proceso', 'Completada', 'Cancelada']),
  ],
  validate,
  requireRole('Coordinadora Institucional', 'Administrador'),
  ctrl.updateByCoord
);

// ── Actividades habilitadas por un tutor (para tutorados) ────────────────────
router.get('/habilitadas/:noEmp', ctrl.getHabilitadasPorTutor);

// ── Tutor habilita/deshabilita una actividad para sus tutorados ───────────────
router.post('/:id/habilitar',
  param('id').isInt({ min: 1 }), validate,
  requireRole('Tutor'),
  ctrl.toggleHabilitar
);

// ── Eliminar (admin/coordinador/tutor solo sus propias actividades) ───────────
router.delete('/:id',
  param('id').isInt({ min: 1 }),
  validate,
  requireRole('Coordinadora Institucional', 'Administrador', 'Tutor'),
  ctrl.remove
);

module.exports = router;
