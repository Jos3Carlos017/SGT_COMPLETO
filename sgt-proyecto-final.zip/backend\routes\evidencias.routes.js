const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/evidencias.controller');
const upload = require('../middlewares/upload');

router.get('/',                      auth, ctrl.getAll);
router.get('/tutor/:noEmp',          auth, ctrl.getByTutor);
router.get('/tutorado/:noControl',   auth, ctrl.getByTutorado);
router.get('/:id/download',          auth, ctrl.download);
router.post('/',                     auth, upload.single('archivo'), ctrl.upload);
router.patch('/:id/evaluar',         auth, ctrl.evaluar);
router.patch('/:id/archivar',        auth, ctrl.archivar);
router.delete('/:id',                auth, ctrl.archivar);

module.exports = router;
