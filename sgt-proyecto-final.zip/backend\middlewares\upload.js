/**
 * Configuración de multer para subida de evidencias digitales (RF-EVD-01).
 * CORRECCIÓN 2: Solo se permiten archivos PDF para evaluación de evidencias.
 * Tamaño máximo: configurable por variable de entorno (default 10MB)
 * @module middlewares/upload
 */

const multer = require('multer');
const path   = require('path');
const fs     = require('fs');

// Crear carpeta de uploads si no existe
const uploadDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename:    (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname)}`);
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// CORRECCIÓN 2: Solo PDF permitido para evidencias de evaluación
// ─────────────────────────────────────────────────────────────────────────────
const MIME_TYPES_PDF = ['application/pdf'];

const fileFilter = (_req, file, cb) => {
  const ext  = path.extname(file.originalname).toLowerCase();
  const mime = file.mimetype;

  if (ext === '.pdf' && MIME_TYPES_PDF.includes(mime)) {
    cb(null, true);
  } else {
    cb(new Error('Solo se permiten archivos en formato PDF para la evaluación de evidencias.'));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: (parseInt(process.env.UPLOAD_MAX_MB) || 10) * 1024 * 1024 },
});

module.exports = upload;
