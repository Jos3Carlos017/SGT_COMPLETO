const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT I.idInforme, I.observaciones, I.estado, I.created_at,
             I.noEmpleado, U.nombre AS tutor,
             I.idPrograma, P.cicloEscolar
      FROM InformeIntermedio I
      INNER JOIN Tutor TU ON TU.noEmpleado = I.noEmpleado
      INNER JOIN Usuario U ON U.idUsuario = TU.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = I.idPrograma
      ORDER BY I.created_at DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { noEmpleado, idPrograma, observaciones } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('noEmpleado',   sql.NVarChar(20),      noEmpleado)
      .input('idPrograma',   sql.Int,                idPrograma)
      .input('observaciones',sql.NVarChar(sql.MAX),  observaciones || null)
      .execute('sp_RegistrarInformeIntermedio');
    return res.status(201).json({ success: true, message: 'Informe registrado' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { observaciones, estado } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('id',           sql.Int,               req.params.id)
      .input('observaciones',sql.NVarChar(sql.MAX),  observaciones || null)
      .input('estado',       sql.NVarChar(20),       estado)
      .query(`UPDATE InformeIntermedio SET observaciones=@observaciones, estado=@estado, updated_at=GETDATE()
              WHERE idInforme=@id`);
    return res.status(200).json({ success: true, message: 'Informe actualizado' });
  } catch (err) { next(err); }
};

const remove = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`DELETE FROM InformeIntermedio WHERE idInforme=@id AND estado='Borrador'`);
    return res.status(200).json({ success: true, message: 'Informe eliminado' });
  } catch (err) { next(err); }
};

module.exports = { getAll, create, update, remove };
