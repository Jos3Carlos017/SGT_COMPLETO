-- ═══════════════════════════════════════════════════════════════════════════
-- SCRIPT DE CORRECCIÓN DE DATOS — Casos de Prueba SGT
-- Ejecutar sobre SISTEMA_TUTORIAS después de la migración base.
-- ═══════════════════════════════════════════════════════════════════════════

USE SISTEMA_TUTORIAS;
GO

-- ─────────────────────────────────────────────────────────────────────────────
-- CU1: Corregir correo de juan.perez y su rol (debe ser Director, no Tutor)
-- ─────────────────────────────────────────────────────────────────────────────
UPDATE Usuario
SET correoInst = 'juan.perez@culiacan.tecnm.mx'
WHERE correoInst LIKE '%juan%perez%'
  AND correoInst <> 'juan.perez@culiacan.tecnm.mx';
PRINT 'Correo de juan.perez corregido.';

-- Si juan.perez debe ser Director (CU1) Y también Tutor (CU5/CU6),
-- esto significa que hay DOS usuarios juan.perez o que el usuario cumple ambos roles.
-- Verificar con SELECT antes de cambiar:
-- SELECT * FROM Usuario WHERE nombre LIKE '%Juan%Perez%' OR correoInst LIKE '%juan.perez%';

-- ─────────────────────────────────────────────────────────────────────────────
-- CU4: Verificar que "Ana Garcia" exista como Tutor (no "Maria Garcia")
-- ─────────────────────────────────────────────────────────────────────────────
IF EXISTS (SELECT 1 FROM Usuario WHERE nombre LIKE '%Maria%Garcia%' AND rol = 'Tutor')
BEGIN
    UPDATE Usuario SET nombre = 'Ana Garcia'
    WHERE nombre LIKE '%Maria%Garcia%' AND rol = 'Tutor';
    PRINT 'Nombre de tutor corregido: Maria Garcia → Ana Garcia.';
END
ELSE
BEGIN
    PRINT 'No se encontró usuario "Maria Garcia" con rol Tutor — verificar manualmente.';
END;

-- ─────────────────────────────────────────────────────────────────────────────
-- Verificar vistas requeridas por reportes.controller.js
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'vw_TutoradosAcreditados')
BEGIN
    EXEC(N'CREATE VIEW vw_TutoradosAcreditados AS
        SELECT T.noControl, U.nombre, T.carrera,
               E.promedio, E.statusDesempeno, P.cicloEscolar
        FROM   Evaluacion E
        JOIN   Tutorado T ON T.noControl = E.noControl
        JOIN   Usuario  U ON U.idUsuario = T.idUsuario
        JOIN   Programa_Tutorias P ON P.idPrograma = E.idPrograma
        WHERE  E.estado IN (''Cerrada'',''Validada'')
          AND  E.statusDesempeno IN (''Sobresaliente'',''Satisfactorio'',''Regular'')
          AND  T.estatus = ''Activo''');
    PRINT 'Vista vw_TutoradosAcreditados creada.';
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'vw_CargaTutores')
BEGIN
    EXEC(N'CREATE VIEW vw_CargaTutores AS
        SELECT T.noEmpleado, U.nombre AS tutor,
               T.cupoDisponible, 25 - T.cupoDisponible AS tutoradosAsignados,
               P.cicloEscolar
        FROM   Tutor T
        JOIN   Usuario U ON U.idUsuario = T.idUsuario
        JOIN   Programa_Tutorias P ON P.estado = ''Activo''');
    PRINT 'Vista vw_CargaTutores creada.';
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'vw_AsistenciaTutorado')
BEGIN
    EXEC(N'CREATE VIEW vw_AsistenciaTutorado AS
        SELECT A.noControl, U.nombre,
               COUNT(*) AS totalSesiones,
               SUM(CASE WHEN A.asistio=1 THEN 1 ELSE 0 END) AS sesionesAsistidas,
               ROUND(CAST(SUM(CASE WHEN A.asistio=1 THEN 1 ELSE 0 END) AS DECIMAL(10,1))
                     / NULLIF(COUNT(*),0)*100, 1) AS porcentajeAsistencia
        FROM   Asistencia A
        JOIN   Tutorado T ON T.noControl = A.noControl
        JOIN   Usuario  U ON U.idUsuario = T.idUsuario
        GROUP BY A.noControl, U.nombre');
    PRINT 'Vista vw_AsistenciaTutorado creada.';
END;

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'vw_ReporteEstadistico')
BEGIN
    EXEC(N'CREATE VIEW vw_ReporteEstadistico AS
        SELECT P.cicloEscolar, T.carrera,
               COUNT(DISTINCT A.noEmpleado) AS totalTutores,
               COUNT(DISTINCT A.noControl)  AS totalTutorados,
               COUNT(DISTINCT B.idBaja)     AS totalBajas
        FROM   Asignacion A
        JOIN   Programa_Tutorias P ON P.idPrograma = A.idPrograma
        JOIN   Tutorado T ON T.noControl = A.noControl
        LEFT JOIN Baja B ON B.noControl = A.noControl
        GROUP BY P.cicloEscolar, T.carrera');
    PRINT 'Vista vw_ReporteEstadistico creada.';
END;

PRINT '✅ Script de corrección de datos completado.';
GO
