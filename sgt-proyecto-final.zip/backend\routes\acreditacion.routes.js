const router = require('express').Router();
const { verifyToken, requireRole } = require('../middlewares/auth');
const ctrl = require('../controllers/acreditacion.controller');

router.use(verifyToken);

router.get('/tutor/:noEmp', ctrl.getByTutor);
router.post('/', requireRole('Tutor','Administrador'), ctrl.acreditar);

module.exports = router;
