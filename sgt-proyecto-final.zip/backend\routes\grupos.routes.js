const router = require('express').Router();
const { verifyToken, requireRole } = require('../middlewares/auth');
const ctrl = require('../controllers/grupos.controller');

router.use(verifyToken);

router.get('/',                ctrl.getAll);
router.get('/tutor/:noEmp',    ctrl.getByTutor);
router.post('/',               requireRole('Jefe Departamento','Administrador','Coordinadora Institucional'), ctrl.create);
router.delete('/:id',          requireRole('Jefe Departamento','Administrador'), ctrl.remove);

module.exports = router;
