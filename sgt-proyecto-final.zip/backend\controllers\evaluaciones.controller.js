const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT E.idEvaluacion, E.noControl, UE.nombre AS tutorado,
             E.noEmpleado, UT.nombre AS tutor,
             E.promedio, E.statusDesempeno, E.estado, E.fechaRegistro,
             E.idPrograma, P.cicloEscolar
      FROM Evaluacion E
      INNER JOIN Tutorado  T  ON T.noControl  = E.noControl
      INNER JOIN Usuario   UE ON UE.idUsuario = T.idUsuario
      INNER JOIN Tutor     TU ON TU.noEmpleado = E.noEmpleado
      INNER JOIN Usuario   UT ON UT.idUsuario  = TU.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = E.idPrograma
      ORDER BY E.fechaRegistro DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getCriterios = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`SELECT numeroCriterio, valor FROM CriterioEvaluacion
              WHERE idEvaluacion = @id ORDER BY numeroCriterio`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { noControl, noEmpleado, idPrograma, criterios } = req.body;
    if (!criterios || criterios.length !== 7)
      return res.status(400).json({ success: false, message: 'Se requieren exactamente 7 criterios' });

    const getVal = (c) => {
      if (c && typeof c === 'object' && 'valor' in c) return parseInt(c.valor);
      return parseInt(c);
    };

    const pool = await getPool();
    await pool.request()
      .input('noControl',  sql.NVarChar(20), noControl)
      .input('noEmpleado', sql.NVarChar(20), noEmpleado)
      .input('idPrograma', sql.Int,          idPrograma)
      .input('c1', sql.SmallInt, getVal(criterios[0])).input('c2', sql.SmallInt, getVal(criterios[1]))
      .input('c3', sql.SmallInt, getVal(criterios[2])).input('c4', sql.SmallInt, getVal(criterios[3]))
      .input('c5', sql.SmallInt, getVal(criterios[4])).input('c6', sql.SmallInt, getVal(criterios[5]))
      .input('c7', sql.SmallInt, getVal(criterios[6]))
      .execute('sp_EvaluarTutorado');
    return res.status(201).json({ success: true, message: 'Evaluación registrada' });
  } catch (err) { next(err); }
};

const validar = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id',   sql.Int, req.params.id)
      .input('uid',  sql.Int, req.usuario.idUsuario)
      .query(`UPDATE Evaluacion SET estado='Validada', validadoPor=@uid, fechaValidacion=GETDATE()
              WHERE idEvaluacion=@id`);
    return res.status(200).json({ success: true, message: 'Evaluación validada' });
  } catch (err) { next(err); }
};

module.exports = { getAll, getCriterios, create, validar };
