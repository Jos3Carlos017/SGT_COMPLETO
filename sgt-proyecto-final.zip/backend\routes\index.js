/**
 * Enrutador principal — agrupa todas las rutas del SGT.
 * @module routes/index
 */

const router = require('express').Router();

router.use('/auth',           require('./auth.routes'));
router.use('/usuarios',       require('./usuarios.routes'));
router.use('/programas',      require('./programas.routes'));
router.use('/tutores',        require('./tutores.routes'));
router.use('/tutorados',      require('./tutorados.routes'));
router.use('/asignaciones',   require('./asignaciones.routes'));   // CORRECCIÓN 1
router.use('/sesiones',       require('./sesiones.routes'));       // CORRECCIÓN 3 y 4
router.use('/evidencias',     require('./evidencias.routes'));     // CORRECCIÓN 2
router.use('/evaluaciones',   require('./evaluaciones.routes'));
router.use('/canalizaciones', require('./canalizaciones.routes'));
router.use('/informes',       require('./informes.routes'));
router.use('/reportes',       require('./reportes.routes'));
router.use('/actividades',    require('./actividades.routes'));    // CORRECCIÓN 5 (nuevo)
router.use('/constancias',    require('./constancias.routes'));    // CP-09
router.use('/bajas',          require('./bajas.routes'));          // CP-12
router.use('/grupos',         require('./grupos.routes'));         // Grupos tutoriales (Jefe Depto)
router.use('/acreditacion',   require('./acreditacion.routes'));   // Acreditación de tutorados

module.exports = router;
