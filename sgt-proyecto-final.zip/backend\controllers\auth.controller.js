const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { getPool, sql } = require('../config/db');

const login = async (req, res, next) => {
  try {
    const { correoInst, password } = req.body;
    if (!correoInst || !password)
      return res.status(400).json({ success: false, message: 'Correo y contraseña requeridos' });

    const pool   = await getPool();
    const result = await pool.request()
      .input('correo', sql.NVarChar(150), correoInst)
      .query(`SELECT idUsuario, nombre, correoInst, passwordHash, rol, estado, numEmpleado, numControl
              FROM Usuario WHERE correoInst = @correo`);

    const user = result.recordset[0];
    if (!user)
      return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
    if (user.estado !== 'Activo')
      return res.status(403).json({ success: false, message: 'Usuario inactivo. Contacta al administrador.' });

    // Primer login: contraseña sin hashear
    if (user.passwordHash === 'CAMBIAR_AL_PRIMER_LOGIN') {
      return res.status(200).json({ success: true, primerLogin: true, idUsuario: user.idUsuario });
    }

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok)
      return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });

    const token = jwt.sign(
      { idUsuario: user.idUsuario, rol: user.rol, nombre: user.nombre,
        numEmpleado: user.numEmpleado || null, numControl: user.numControl || null },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES || '8h' }
    );

    return res.status(200).json({
      success: true,
      data: {
        token,
        usuario: {
          idUsuario:   user.idUsuario,
          nombre:      user.nombre,
          correoInst:  user.correoInst,
          rol:         user.rol,
          numEmpleado: user.numEmpleado || null,
          numControl:  user.numControl  || null,
        }
      }
    });
  } catch (err) { next(err); }
};

const cambiarPassword = async (req, res, next) => {
  try {
    const { idUsuario, nuevaPassword, passwordActual } = req.body;
    if (!idUsuario || !nuevaPassword)
      return res.status(400).json({ success: false, message: 'Datos requeridos' });
    if (nuevaPassword.length < 8)
      return res.status(400).json({ success: false, message: 'La nueva contraseña debe tener mínimo 8 caracteres' });

    const pool   = await getPool();
    const found  = await pool.request()
      .input('id', sql.Int, idUsuario)
      .query(`SELECT passwordHash FROM Usuario WHERE idUsuario = @id`);

    if (!found.recordset[0])
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });

    const hashActual = found.recordset[0].passwordHash;

    // Si tiene contraseña real, verificar la actual
    if (hashActual !== 'CAMBIAR_AL_PRIMER_LOGIN') {
      if (!passwordActual)
        return res.status(400).json({ success: false, message: 'La contraseña actual es requerida' });
      const ok = await bcrypt.compare(passwordActual, hashActual);
      if (!ok)
        return res.status(401).json({ success: false, message: 'La contraseña actual es incorrecta' });
    }

    const hash = await bcrypt.hash(nuevaPassword, 10);
    await pool.request()
      .input('id',   sql.Int,          idUsuario)
      .input('hash', sql.NVarChar(255), hash)
      .query(`UPDATE Usuario SET passwordHash = @hash WHERE idUsuario = @id`);

    return res.status(200).json({ success: true, message: 'Contraseña actualizada correctamente' });
  } catch (err) { next(err); }
};

// Cambio de contraseña en primer acceso (sin token) — solo funciona si aún tiene CAMBIAR_AL_PRIMER_LOGIN
const primerAcceso = async (req, res, next) => {
  try {
    const { correoInst, nuevaPassword } = req.body;
    if (!correoInst || !nuevaPassword)
      return res.status(400).json({ success: false, message: 'Correo y contraseña son requeridos' });
    if (nuevaPassword.length < 8)
      return res.status(400).json({ success: false, message: 'La contraseña debe tener mínimo 8 caracteres' });

    const pool  = await getPool();
    const found = await pool.request()
      .input('correo', sql.NVarChar(150), correoInst)
      .query(`SELECT idUsuario, passwordHash FROM Usuario WHERE correoInst = @correo`);

    const user = found.recordset[0];
    if (!user)
      return res.status(404).json({ success: false, message: 'No existe un usuario con ese correo' });
    if (user.passwordHash !== 'CAMBIAR_AL_PRIMER_LOGIN')
      return res.status(400).json({ success: false, message: 'Este usuario ya tiene contraseña configurada. Usa el login normal.' });

    const hash = await bcrypt.hash(nuevaPassword, 10);
    await pool.request()
      .input('id',   sql.Int,          user.idUsuario)
      .input('hash', sql.NVarChar(255), hash)
      .query(`UPDATE Usuario SET passwordHash = @hash WHERE idUsuario = @id`);

    return res.status(200).json({ success: true, message: 'Contraseña configurada. Ya puedes iniciar sesión.' });
  } catch (err) { next(err); }
};

module.exports = { login, cambiarPassword, primerAcceso };
