const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/programas.controller');

router.get('/',              auth, ctrl.getAll);
router.get('/:id',           auth, ctrl.getOne);
router.post('/',             auth, ctrl.create);
router.put('/:id',           auth, ctrl.update);
router.patch('/:id/estado',  auth, ctrl.cambiarEstado);

module.exports = router;
