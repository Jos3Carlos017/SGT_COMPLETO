const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/reportes.controller');

router.get('/sesiones-tutor',   auth, ctrl.sesionesXTutor);
router.get('/tutorados-riesgo', auth, ctrl.tutoradosRiesgo);
router.get('/avance-programa',  auth, ctrl.avancePrograma);
router.get('/canalizaciones',   auth, ctrl.canalizacionesReporte);

router.get('/estadistico',      auth, ctrl.avancePrograma);
router.get('/acreditados',      auth, ctrl.tutoradosAcreditados);
router.get('/carga-tutores',    auth, ctrl.cargaTutores);
router.get('/asistencia',       auth, ctrl.asistenciaGeneral);

module.exports = router;
