-- ═══════════════════════════════════════════════════════════════════════════
-- MIGRACIÓN V6 — Habilitación de actividades por tutor
-- Ejecutar UNA SOLA VEZ en SSMS sobre la base SISTEMA_TUTORIAS existente.
-- ═══════════════════════════════════════════════════════════════════════════
USE SISTEMA_TUTORIAS;
GO

IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'ActividadTutorHabilitada'
)
BEGIN
  CREATE TABLE ActividadTutorHabilitada (
    idActHab    INT           IDENTITY(1,1) PRIMARY KEY,
    idActividad INT           NOT NULL REFERENCES Actividad(idActividad),
    noEmpleado  NVARCHAR(20)  NOT NULL REFERENCES Tutor(noEmpleado),
    habilitada  BIT           NOT NULL DEFAULT 1,
    fechaHab    DATETIME2     NOT NULL DEFAULT GETDATE(),
    CONSTRAINT uq_act_tutor UNIQUE (idActividad, noEmpleado)
  );
  PRINT 'Tabla ActividadTutorHabilitada creada.';
END
ELSE PRINT 'Tabla ActividadTutorHabilitada ya existe.';
GO

SELECT 'Migración V6 completada correctamente.' AS Resultado;
GO
