const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/tutores.controller');

router.get('/',                    auth, ctrl.getAll);
router.get('/:noEmpleado',         auth, ctrl.getOne);
router.post('/',                   auth, ctrl.create);
router.put('/:noEmpleado',         auth, ctrl.update);
router.patch('/:noEmpleado/baja',  auth, ctrl.desactivar);
router.delete('/:noEmpleado',      auth, ctrl.desactivar);

module.exports = router;
