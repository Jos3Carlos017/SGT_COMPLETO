-- ═══════════════════════════════════════════════════════════════════════════
-- MIGRACIÓN V5 — Grupos Tutoriales
-- Ejecutar UNA SOLA VEZ en SSMS sobre la base SISTEMA_TUTORIAS existente.
-- ═══════════════════════════════════════════════════════════════════════════

USE SISTEMA_TUTORIAS;
GO

-- Tabla GrupoTutor: asignación de tutor a grupo (Jefe Departamento la gestiona)
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'GrupoTutor'
)
BEGIN
  CREATE TABLE GrupoTutor (
    idGrupo     INT           IDENTITY(1,1) PRIMARY KEY,
    noEmpleado  NVARCHAR(20)  NOT NULL REFERENCES Tutor(noEmpleado),
    idPrograma  INT           NOT NULL REFERENCES Programa_Tutorias(idPrograma),
    carrera     NVARCHAR(100) NOT NULL,
    nombreGrupo NVARCHAR(50)  NOT NULL,   -- ej: "A", "ISC-2026A"
    salon       NVARCHAR(20)  NOT NULL,
    dia         NVARCHAR(20)  NOT NULL,   -- ej: "Lunes"
    horaInicio  NVARCHAR(10)  NOT NULL,   -- ej: "10:00"
    horaFin     NVARCHAR(10)  NOT NULL,   -- ej: "11:00"
    estado      NVARCHAR(20)  NOT NULL DEFAULT 'Activo',
    creadoEn    DATETIME2     NOT NULL DEFAULT GETDATE(),

    -- Un tutor solo puede tener un grupo por programa
    CONSTRAINT uq_tutor_programa_grupo UNIQUE (noEmpleado, idPrograma)
  );
  PRINT 'Tabla GrupoTutor creada.';
END
ELSE PRINT 'Tabla GrupoTutor ya existe.';
GO

SELECT 'Migración V5 completada correctamente.' AS Resultado;
GO
