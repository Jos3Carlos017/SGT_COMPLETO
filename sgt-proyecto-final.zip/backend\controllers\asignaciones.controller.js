/**
 * Controlador de asignaciones (RF-ASI-01)
 * El trigger trg_ValidarCupoTutor valida el límite de 25 automáticamente.
 * CORRECCIÓN: Asignación de tutores a tutorados con validaciones completas.
 * @module controllers/asignaciones
 */
const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT A.idAsignacion, A.noEmpleado, UT.nombre AS tutor,
             A.noControl, UE.nombre AS tutorado, TU.carrera,
             A.periodo, A.estado, A.aula, A.horario, A.fecha
      FROM   Asignacion A
      INNER JOIN Tutor   T  ON T.noEmpleado  = A.noEmpleado
      INNER JOIN Usuario UT ON UT.idUsuario  = T.idUsuario
      INNER JOIN Tutorado TU ON TU.noControl = A.noControl
      INNER JOIN Usuario UE ON UE.idUsuario  = TU.idUsuario
      ORDER BY A.fecha DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getByTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noEmp', sql.VarChar(20), req.params.noEmp)
      .query(`SELECT A.idAsignacion, A.noControl, U.nombre AS tutorado,
                     TU.carrera, TU.semestre, A.periodo, A.estado,
                     A.noEmpleado, A.idPrograma, A.aula, A.horario
              FROM   Asignacion A
              INNER JOIN Tutorado TU ON TU.noControl = A.noControl
              INNER JOIN Usuario  U  ON U.idUsuario  = TU.idUsuario
              WHERE  A.noEmpleado = @noEmp AND A.estado = 'Activa'
              ORDER BY U.nombre`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getById = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`SELECT A.*, UT.nombre AS tutor, UE.nombre AS tutorado
              FROM   Asignacion A
              INNER JOIN Tutor   T  ON T.noEmpleado  = A.noEmpleado
              INNER JOIN Usuario UT ON UT.idUsuario  = T.idUsuario
              INNER JOIN Tutorado TU ON TU.noControl = A.noControl
              INNER JOIN Usuario UE ON UE.idUsuario  = TU.idUsuario
              WHERE A.idAsignacion = @id`);
    if (!result.recordset[0])
      return res.status(404).json({ success: false, message: 'Asignación no encontrada.' });
    return res.status(200).json({ success: true, data: result.recordset[0] });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// CORRECCIÓN 1: Asignación de tutor a tutorado con validaciones previas
// ─────────────────────────────────────────────────────────────────────────────
const create = async (req, res, next) => {
  try {
    const { noEmpleado, noControl, periodo, idPrograma, aula, horario, idCoordDepto } = req.body;
    const pool = await getPool();

    // Validar que el tutor exista y esté activo
    const tutorCheck = await pool.request()
      .input('noEmp', sql.VarChar(20), noEmpleado)
      .query(`SELECT T.noEmpleado, T.cupoDisponible, U.estado, U.nombre
              FROM Tutor T INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
              WHERE T.noEmpleado = @noEmp`);
    if (!tutorCheck.recordset[0])
      return res.status(404).json({ success: false, message: 'El tutor especificado no existe.' });
    if (tutorCheck.recordset[0].estado !== 'Activo')
      return res.status(400).json({ success: false, message: 'El tutor no está activo.' });
    if (tutorCheck.recordset[0].cupoDisponible <= 0)
      return res.status(400).json({ success: false, message: 'El tutor no tiene cupo disponible (máximo 25 tutorados).' });

    // Validar que el tutorado exista y esté activo
    const tutoradoCheck = await pool.request()
      .input('noControl', sql.VarChar(20), noControl)
      .query(`SELECT T.noControl, U.estado, U.nombre
              FROM Tutorado T INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
              WHERE T.noControl = @noControl`);
    if (!tutoradoCheck.recordset[0])
      return res.status(404).json({ success: false, message: 'El tutorado especificado no existe.' });
    if (tutoradoCheck.recordset[0].estado !== 'Activo')
      return res.status(400).json({ success: false, message: 'El tutorado no está activo.' });

    // Validar que el tutorado no tenga ya una asignación activa en el mismo programa
    const asigExiste = await pool.request()
      .input('noControl',  sql.VarChar(20), noControl)
      .input('idPrograma', sql.Int,         idPrograma)
      .query(`SELECT idAsignacion FROM Asignacion
              WHERE noControl = @noControl AND idPrograma = @idPrograma AND estado = 'Activa'`);
    if (asigExiste.recordset[0])
      return res.status(409).json({ success: false, message: 'El tutorado ya tiene una asignación activa en este programa.' });

    // Validar que el programa exista y esté activo
    const programaCheck = await pool.request()
      .input('idPrograma', sql.Int, idPrograma)
      .query(`SELECT idPrograma, estado FROM Programa_Tutorias WHERE idPrograma = @idPrograma`);
    if (!programaCheck.recordset[0])
      return res.status(404).json({ success: false, message: 'El programa especificado no existe.' });
    if (programaCheck.recordset[0].estado !== 'Activo')
      return res.status(400).json({ success: false, message: 'El programa no está activo.' });

    // Validar conflicto de aula+horario (misma aula y horario en el mismo programa, tutor distinto)
    if (aula && horario) {
      const conflicto = await pool.request()
        .input('aula',      sql.NVarChar(20),  aula)
        .input('horario',   sql.NVarChar(50),  horario)
        .input('idPrograma',sql.Int,           idPrograma)
        .input('noEmpleado',sql.VarChar(20),   noEmpleado)
        .query(`
          SELECT DISTINCT A.noEmpleado, U.nombre AS tutor
          FROM   Asignacion A
          INNER  JOIN Tutor    T ON T.noEmpleado = A.noEmpleado
          INNER  JOIN Usuario  U ON U.idUsuario  = T.idUsuario
          WHERE  A.aula       = @aula
            AND  A.horario    = @horario
            AND  A.idPrograma = @idPrograma
            AND  A.noEmpleado != @noEmpleado
            AND  A.estado     = 'Activa'
        `);
      if (conflicto.recordset[0]) {
        return res.status(409).json({
          success: false,
          message: `Conflicto de horario: El aula "${aula}" ya está ocupada el "${horario}" por el tutor "${conflicto.recordset[0].tutor}". Elige otro aula u horario.`,
        });
      }
    }

    // Ejecutar procedimiento de asignación
    await pool.request()
      .input('noEmpleado',   sql.VarChar(20), noEmpleado)
      .input('noControl',    sql.VarChar(20), noControl)
      .input('periodo',      sql.VarChar(50), periodo)
      .input('idPrograma',   sql.Int,         idPrograma)
      .input('idCoordDepto', sql.Int,         idCoordDepto || null)
      .execute('sp_AsignarTutorado');

    // Actualizar aula/horario si se proporcionaron
    if (aula || horario) {
      await pool.request()
        .input('noEmpleado', sql.VarChar(20),  noEmpleado)
        .input('noControl',  sql.VarChar(20),  noControl)
        .input('idPrograma', sql.Int,          idPrograma)
        .input('aula',       sql.NVarChar(20), aula    || null)
        .input('horario',    sql.NVarChar(50), horario || null)
        .query(`UPDATE Asignacion SET aula=@aula, horario=@horario
                WHERE noEmpleado=@noEmpleado AND noControl=@noControl AND idPrograma=@idPrograma`);
    }

    return res.status(201).json({
      success: true,
      message: `Tutorado "${tutoradoCheck.recordset[0].nombre}" asignado correctamente al tutor "${tutorCheck.recordset[0].nombre}".`,
    });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { aula, horario, estado } = req.body;
    const pool  = await getPool();
    const check = await pool.request().input('id', sql.Int, req.params.id)
      .query('SELECT idAsignacion FROM Asignacion WHERE idAsignacion = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Asignación no encontrada.' });
    await pool.request()
      .input('id',      sql.Int,         req.params.id)
      .input('aula',    sql.NVarChar(20), aula    || null)
      .input('horario', sql.NVarChar(50), horario || null)
      .input('estado',  sql.NVarChar(20), estado  || null)
      .query(`UPDATE Asignacion SET aula=COALESCE(@aula,aula), horario=COALESCE(@horario,horario),
              estado=COALESCE(@estado,estado) WHERE idAsignacion=@id`);
    return res.status(200).json({ success: true, message: 'Asignación actualizada.' });
  } catch (err) { next(err); }
};

const remove = async (req, res, next) => {
  try {
    const pool  = await getPool();
    const check = await pool.request().input('id', sql.Int, req.params.id)
      .query('SELECT idAsignacion, noEmpleado FROM Asignacion WHERE idAsignacion = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Asignación no encontrada.' });
    await pool.request().input('noEmp', sql.VarChar(20), check.recordset[0].noEmpleado)
      .query(`UPDATE Tutor SET cupoDisponible = cupoDisponible + 1 WHERE noEmpleado = @noEmp`);
    await pool.request().input('id', sql.Int, req.params.id)
      .query('DELETE FROM Asignacion WHERE idAsignacion = @id');
    return res.status(200).json({ success: true, message: 'Asignación eliminada y cupo liberado.' });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// CORRECCIÓN 1 (extra): Obtener tutorados disponibles para asignar a un tutor
// ─────────────────────────────────────────────────────────────────────────────
const getTutoradosDisponibles = async (req, res, next) => {
  try {
    const { idPrograma } = req.query;
    const pool = await getPool();
    const request = pool.request();
    let query = `
      SELECT T.noControl, U.nombre, T.carrera, T.semestre
      FROM   Tutorado T
      INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
      WHERE  U.estado  = 'Activo'
        AND  T.estatus = 'Activo'
        AND  T.noControl NOT IN (
               SELECT noControl FROM Asignacion
               WHERE estado = 'Activa'
               ${idPrograma ? 'AND idPrograma = @idPrograma' : ''}
             )
      ORDER BY U.nombre`;
    if (idPrograma) request.input('idPrograma', sql.Int, idPrograma);
    const result = await request.query(query);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// Obtiene la asignación de un tutorado (su tutor y programa)
const getByTutorado = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('nc', sql.VarChar(20), req.params.noControl)
      .query(`SELECT A.noEmpleado, A.idPrograma, A.periodo, A.aula, A.horario,
                     T.nombre AS tutor
              FROM   Asignacion A
              INNER  JOIN Tutor   TU ON TU.noEmpleado = A.noEmpleado
              INNER  JOIN Usuario T  ON T.idUsuario   = TU.idUsuario
              WHERE  A.noControl = @nc AND A.estado = 'Activa'`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

module.exports = { getAll, getByTutor, getByTutorado, getById, create, update, remove, getTutoradosDisponibles };
