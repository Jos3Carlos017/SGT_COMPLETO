const { getPool } = require('../config/db');

const sesionesXTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT U.nombre AS tutor, TU.noEmpleado,
             COUNT(S.idSesion) AS totalSesiones,
             SUM(CASE WHEN S.conEvidencia=1 THEN 1 ELSE 0 END) AS conEvidencia,
             P.cicloEscolar
      FROM Sesion S
      INNER JOIN Tutor TU ON TU.noEmpleado = S.noEmpleado
      INNER JOIN Usuario U ON U.idUsuario = TU.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = S.idPrograma
      GROUP BY U.nombre, TU.noEmpleado, P.cicloEscolar
      ORDER BY totalSesiones DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const tutoradosRiesgo = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT T.noControl, U.nombre, T.carrera, T.semestre,
             E.promedio, E.statusDesempeno,
             ast.porcentajeAsistencia
      FROM Tutorado T
      INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
      LEFT JOIN Evaluacion E ON E.noControl = T.noControl
      LEFT JOIN vw_AsistenciaTutorado ast ON ast.noControl = T.noControl
      WHERE (E.statusDesempeno IN ('Deficiente','Regular') OR ast.porcentajeAsistencia < 50)
        AND T.estatus = 'Activo'
      ORDER BY ast.porcentajeAsistencia ASC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const avancePrograma = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`SELECT * FROM vw_ReporteEstadistico`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const canalizacionesReporte = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT C.tipoAtencion, C.estatus, COUNT(*) AS total, P.cicloEscolar
      FROM Canalizacion C
      INNER JOIN Programa_Tutorias P ON P.idPrograma = C.idPrograma
      GROUP BY C.tipoAtencion, C.estatus, P.cicloEscolar
      ORDER BY total DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const tutoradosAcreditados = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT T.noControl, U.nombre, T.carrera,
             E.promedio, E.statusDesempeno,
             ISNULL(A.periodo, P.cicloEscolar) AS periodo
      FROM   Evaluacion E
      JOIN   Tutorado T  ON T.noControl  = E.noControl
      JOIN   Usuario  U  ON U.idUsuario  = T.idUsuario
      JOIN   Programa_Tutorias P ON P.idPrograma = E.idPrograma
      LEFT   JOIN Asignacion A ON A.noControl = T.noControl AND A.noEmpleado = E.noEmpleado AND A.estado = 'Activa'
      WHERE  E.estado IN ('Cerrada','Validada')
        AND  E.statusDesempeno IN ('Sobresaliente','Satisfactorio','Regular','Excelente','Bueno','Aceptable','Suficiente')
        AND  T.estatus = 'Activo'
      ORDER  BY E.fechaRegistro DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const cargaTutores = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`SELECT * FROM vw_CargaTutores ORDER BY tutoradosAsignados DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const asistenciaGeneral = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`SELECT * FROM vw_AsistenciaTutorado ORDER BY porcentajeAsistencia ASC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

module.exports = { sesionesXTutor, tutoradosRiesgo, avancePrograma, canalizacionesReporte, tutoradosAcreditados, cargaTutores, asistenciaGeneral };
