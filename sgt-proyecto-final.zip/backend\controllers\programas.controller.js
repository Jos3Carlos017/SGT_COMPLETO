const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT P.idPrograma, P.cicloEscolar, P.objetivo, P.fechaInicio, P.fechaFin, P.estado,
             U.nombre AS coordinadora
      FROM Programa_Tutorias P
      INNER JOIN Coordinadora_Institucional CI ON CI.idCoordInst = P.idCoordInst
      INNER JOIN Usuario U ON U.idUsuario = CI.idUsuario
      ORDER BY P.fechaInicio DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getOne = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`SELECT * FROM Programa_Tutorias WHERE idPrograma = @id`);
    if (!result.recordset[0]) return res.status(404).json({ success: false, message: 'Programa no encontrado' });
    return res.status(200).json({ success: true, data: result.recordset[0] });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { cicloEscolar, objetivo, fechaInicio, fechaFin, idCoordInst } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('ciclo',      sql.NVarChar(30),  cicloEscolar)
      .input('objetivo',   sql.NVarChar(500), objetivo || null)
      .input('inicio',     sql.Date,          fechaInicio)
      .input('fin',        sql.Date,          fechaFin)
      .input('coordInst',  sql.Int,           idCoordInst)
      .query(`INSERT INTO Programa_Tutorias(cicloEscolar,objetivo,fechaInicio,fechaFin,estado,idITC,idCoordInst)
              VALUES(@ciclo,@objetivo,@inicio,@fin,'Borrador',1,@coordInst)`);
    return res.status(201).json({ success: true, message: 'Programa creado' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { objetivo, fechaFin, estado } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('id',       sql.Int,          req.params.id)
      .input('objetivo', sql.NVarChar(500), objetivo || null)
      .input('fin',      sql.Date,          fechaFin)
      .input('estado',   sql.NVarChar(20),  estado)
      .query(`UPDATE Programa_Tutorias SET objetivo=@objetivo, fechaFin=@fin, estado=@estado
              WHERE idPrograma=@id`);
    return res.status(200).json({ success: true, message: 'Programa actualizado' });
  } catch (err) { next(err); }
};

const cambiarEstado = async (req, res, next) => {
  try {
    const { estado } = req.body;
    const estadosValidos = ['Borrador', 'Activo', 'Cerrado'];
    if (!estado || !estadosValidos.includes(estado))
      return res.status(400).json({ success: false, message: `Estado inválido. Use: ${estadosValidos.join(', ')}` });
    const pool = await getPool();
    const check = await pool.request().input('id', sql.Int, req.params.id)
      .query('SELECT idPrograma FROM Programa_Tutorias WHERE idPrograma = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Programa no encontrado' });
    await pool.request()
      .input('id',     sql.Int,         req.params.id)
      .input('estado', sql.NVarChar(20), estado)
      .query('UPDATE Programa_Tutorias SET estado=@estado WHERE idPrograma=@id');
    return res.status(200).json({ success: true, message: `Programa actualizado a estado "${estado}"` });
  } catch (err) { next(err); }
};

module.exports = { getAll, getOne, create, update, cambiarEstado };
