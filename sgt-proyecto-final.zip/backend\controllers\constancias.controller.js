const { getPool, sql } = require('../config/db');

const getConstancia = async (req, res, next) => {
  try {
    const { noControl } = req.params;
    const pool   = await getPool();
    const result = await pool.request()
      .input('nc', sql.NVarChar(20), noControl)
      .query(`
        SELECT TOP 1
               T.noControl, U.nombre, T.carrera, T.semestre, T.estatus,
               E.promedio,
               CASE
                 WHEN E.statusDesempeno IS NOT NULL THEN E.statusDesempeno
                 WHEN E.promedio >= 4 THEN 'Excelente'
                 WHEN E.promedio >= 3 THEN 'Bueno'
                 WHEN E.promedio >= 2 THEN 'Aceptable'
                 WHEN E.promedio >= 1 THEN 'Suficiente'
                 ELSE NULL
               END AS statusDesempeno,
               E.estado AS estadoEval,
               P.cicloEscolar, P.fechaFin,
               UT.nombre AS tutor
        FROM Tutorado T
        INNER JOIN Usuario U  ON U.idUsuario  = T.idUsuario
        LEFT JOIN Evaluacion E ON E.noControl = T.noControl
        LEFT JOIN Programa_Tutorias P ON P.idPrograma = E.idPrograma
        LEFT JOIN Tutor   TU ON TU.noEmpleado = E.noEmpleado
        LEFT JOIN Usuario UT ON UT.idUsuario  = TU.idUsuario
        WHERE T.noControl = @nc
        ORDER BY
          CASE WHEN E.estado IN ('Validada','Cerrada') THEN 0 ELSE 1 END,
          E.fechaRegistro DESC
      `);

    if (!result.recordset[0])
      return res.status(404).json({ success: false, message: 'No se encontró ningún alumno con ese número de control' });

    const alumno = result.recordset[0];
    const NIVELES_ACREDITADOS = [
      'Sobresaliente','Satisfactorio','Regular',   // escala antigua
      'Excelente','Bueno','Aceptable','Suficiente' // escala nueva
    ];
    const acreditado = alumno.statusDesempeno &&
      NIVELES_ACREDITADOS.includes(alumno.statusDesempeno) &&
      alumno.estatus === 'Activo' &&
      alumno.estadoEval !== null;

    if (!acreditado) {
      let motivo = 'El alumno no cumple los requisitos para generar constancia.';
      if (!alumno.estadoEval)     motivo = 'El alumno no tiene ninguna evaluación registrada.';
      if (!alumno.statusDesempeno) motivo = 'El alumno tiene evaluación pero sin nivel de desempeño asignado.';
      if (alumno.estatus !== 'Activo') motivo = 'El alumno no está activo en el programa.';
      return res.status(400).json({ success: false, message: motivo });
    }

    return res.status(200).json({ success: true, data: { ...alumno, acreditado: true } });
  } catch (err) { next(err); }
};

const registrarEmision = async (req, res, next) => {
  try {
    const { noControl } = req.params;
    const pool = await getPool();
    await pool.request()
      .input('nc',  sql.NVarChar(20), noControl)
      .input('uid', sql.Int,          req.usuario.idUsuario)
      .query(`INSERT INTO Bitacora(accion, tablaAfectada, registroId, datosNuevos, idUsuario)
              VALUES('Crear','Constancia',NULL,@nc,@uid)`);
    return res.status(200).json({ success: true, message: 'Emisión registrada' });
  } catch (err) { next(err); }
};

module.exports = { getConstancia, registrarEmision };
