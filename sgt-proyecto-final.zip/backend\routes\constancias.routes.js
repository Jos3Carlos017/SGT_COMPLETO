const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/constancias.controller');

router.get('/:noControl',        auth, ctrl.getConstancia);
router.post('/:noControl/emitir',auth, ctrl.registrarEmision);

module.exports = router;
