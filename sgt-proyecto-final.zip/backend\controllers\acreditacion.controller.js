const { getPool, sql } = require('../config/db');

const MIN_EVIDENCIAS  = 5;
const MIN_ASISTENCIAS = 5;

// GET /acreditacion/tutor/:noEmp — tutorados con sus stats
const getByTutor = async (req, res, next) => {
  try {
    const pool = await getPool();
    const listRes = await pool.request()
      .input('noEmp', sql.VarChar(20), req.params.noEmp)
      .query(`
        SELECT A.noControl, A.idPrograma,
               U.nombre AS tutorado, T.carrera, T.semestre
        FROM   Asignacion A
        INNER  JOIN Tutorado T ON T.noControl = A.noControl
        INNER  JOIN Usuario  U ON U.idUsuario  = T.idUsuario
        WHERE  A.noEmpleado = @noEmp AND A.estado = 'Activa'
        ORDER  BY U.nombre`);

    const result = [];
    for (const t of listRes.recordset) {
      const [evR, asR, evalR] = await Promise.all([
        // Evidencias aprobadas (calificacion empieza con 'Aceptada')
        pool.request().input('nc', sql.VarChar(20), t.noControl)
          .query(`SELECT COUNT(*) AS total FROM Evidencia
                  WHERE noControl=@nc AND estado='Activa'
                  AND calificacion LIKE 'Aceptada%'`),
        // Asistencias (asistio=1)
        pool.request().input('nc', sql.VarChar(20), t.noControl)
          .query(`SELECT COUNT(*) AS total FROM Asistencia
                  WHERE noControl=@nc AND asistio=1`),
        // Evaluación existente
        pool.request().input('nc', sql.VarChar(20), t.noControl)
          .input('prog', sql.Int, t.idPrograma)
          .query(`SELECT TOP 1 idEvaluacion, statusDesempeno, promedio, estado
                  FROM Evaluacion
                  WHERE noControl=@nc AND idPrograma=@prog
                  ORDER BY fechaRegistro DESC`),
      ]);

      const acreditado = evalR.recordset[0]?.estado === 'Cerrada' ||
                         evalR.recordset[0]?.estado === 'Validada';
      result.push({
        ...t,
        evidenciasAprobadas: evR.recordset[0].total,
        asistencias:         asR.recordset[0].total,
        acreditado,
        statusDesempeno: evalR.recordset[0]?.statusDesempeno || null,
        promedio:        evalR.recordset[0]?.promedio        || null,
        cumpleEvidencias: evR.recordset[0].total >= MIN_EVIDENCIAS,
        cumpleAsistencias: asR.recordset[0].total >= MIN_ASISTENCIAS,
      });
    }

    return res.status(200).json({ success: true, data: result });
  } catch (err) { next(err); }
};

// POST /acreditacion — acredita un tutorado
const acreditar = async (req, res, next) => {
  try {
    const { noControl, noEmpleado, idPrograma } = req.body;
    if (!noControl || !noEmpleado || !idPrograma)
      return res.status(400).json({ success: false, message: 'Datos requeridos.' });

    const pool = await getPool();

    // Verificar requisitos
    const [evR, asR] = await Promise.all([
      pool.request().input('nc', sql.VarChar(20), noControl)
        .query(`SELECT COUNT(*) AS total FROM Evidencia
                WHERE noControl=@nc AND estado='Activa'
                AND calificacion LIKE 'Aceptada%'`),
      pool.request().input('nc', sql.VarChar(20), noControl)
        .query(`SELECT COUNT(*) AS total FROM Asistencia
                WHERE noControl=@nc AND asistio=1`),
    ]);

    const evidencias  = evR.recordset[0].total;
    const asistencias = asR.recordset[0].total;

    if (evidencias < MIN_EVIDENCIAS)
      return res.status(400).json({ success: false,
        message: `Faltan evidencias aprobadas: tiene ${evidencias}, se requieren ${MIN_EVIDENCIAS}.` });
    if (asistencias < MIN_ASISTENCIAS)
      return res.status(400).json({ success: false,
        message: `Faltan asistencias: tiene ${asistencias}, se requieren ${MIN_ASISTENCIAS}.` });

    // ¿Ya tiene evaluación?
    const existing = await pool.request()
      .input('nc',   sql.VarChar(20), noControl)
      .input('prog', sql.Int,         idPrograma)
      .query(`SELECT idEvaluacion FROM Evaluacion
              WHERE noControl=@nc AND idPrograma=@prog`);

    if (existing.recordset[0]) {
      // Actualizar la existente
      await pool.request()
        .input('nc',   sql.VarChar(20), noControl)
        .input('prog', sql.Int,         idPrograma)
        .query(`UPDATE Evaluacion
                SET statusDesempeno='Suficiente', estado='Cerrada', promedio=3,
                    fechaRegistro=GETDATE()
                WHERE noControl=@nc AND idPrograma=@prog`);
    } else {
      // Crear nueva via SP (criterios = 3 por defecto)
      await pool.request()
        .input('noControl',  sql.NVarChar(20), noControl)
        .input('noEmpleado', sql.NVarChar(20), noEmpleado)
        .input('idPrograma', sql.Int,          idPrograma)
        .input('c1', sql.SmallInt, 3).input('c2', sql.SmallInt, 3)
        .input('c3', sql.SmallInt, 3).input('c4', sql.SmallInt, 3)
        .input('c5', sql.SmallInt, 3).input('c6', sql.SmallInt, 3)
        .input('c7', sql.SmallInt, 3)
        .execute('sp_EvaluarTutorado');
    }

    return res.status(200).json({ success: true,
      message: 'Tutorado acreditado correctamente. Ya puede generar su constancia.' });
  } catch (err) { next(err); }
};

module.exports = { getByTutor, acreditar };
