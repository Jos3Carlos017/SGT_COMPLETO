/**
 * Rutas de sesiones (RF-SES-01)
 * CORRECCIÓN 3: Campo tutorAsistio en asistencia.
 * CORRECCIÓN 4: Validación de fechaLimiteEntrega <= fecha actual.
 * @module routes/sesiones
 */
const router                       = require('express').Router();
const { body, param }              = require('express-validator');
const validate                     = require('../middlewares/validate');
const { verifyToken, requireRole } = require('../middlewares/auth');
const ctrl                         = require('../controllers/sesiones.controller');

router.use(verifyToken);

router.get('/',                    ctrl.getAll);
router.get('/tutor/:noEmp',        ctrl.getByTutor);
router.get('/tutorado/:noControl', ctrl.getByTutorado);
router.get('/:id',                 param('id').isInt({ min: 1 }), validate, ctrl.getById);

// Panel de asistencia completo: todos los tutorados del tutor con su estado en esa sesión
router.get('/:idSesion/asistencia-completa/:noEmp',
  param('idSesion').isInt({ min: 1 }),
  validate,
  ctrl.getAsistenciaBySesion
);

// Encuentra o crea la sesión correspondiente a una actividad (para panel de asistencia)
router.post('/from-actividad', verifyToken, requireRole('Tutor'), ctrl.getOrCreateFromActividad);

router.post('/',
  [
    body('numSesion').isInt({ min: 1, max: 8 }).withMessage('numSesion debe ser entre 1 y 8.'),
    body('fecha').isDate().withMessage('Fecha inválida.'),
    body('noEmpleado').notEmpty(),
    body('idPrograma').isInt({ min: 1 }),
    body('fechaLimiteEntrega').optional().isDate().withMessage('Fecha límite inválida.'),
  ],
  validate,
  requireRole('Tutor'),
  ctrl.create
);

router.put('/:id',
  [
    param('id').isInt({ min: 1 }),
    body('fechaLimiteEntrega').optional().isDate().withMessage('Fecha límite inválida.'),
  ],
  validate,
  requireRole('Tutor'),
  ctrl.update
);

router.post('/:id/asistencia',
  [
    param('id').isInt({ min: 1 }),
    body('asistencias').isArray({ min: 1 }),
    body('asistencias.*.noControl').notEmpty(),
    body('asistencias.*.asistio').isBoolean(),
    body('asistencias.*.justificado').optional().isBoolean(),
    body('tutorAsistio').isBoolean().withMessage('Debe indicar si el tutor asistió (tutorAsistio: true/false).'),
  ],
  validate,
  requireRole('Tutor'),
  ctrl.registrarAsistencia
);

module.exports = router;
