const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT B.idBaja, B.motivoBaja, B.fechaUltimaSesion, B.fechaRegistro,
             B.noControl, UE.nombre AS tutorado, T.carrera,
             B.noEmpleado, UT.nombre AS tutor,
             P.cicloEscolar
      FROM Baja B
      INNER JOIN Tutorado  TD ON TD.noControl   = B.noControl
      INNER JOIN Usuario   UE ON UE.idUsuario   = TD.idUsuario
      INNER JOIN Tutor     TU ON TU.noEmpleado  = B.noEmpleado
      INNER JOIN Usuario   UT ON UT.idUsuario   = TU.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = B.idPrograma
      INNER JOIN Tutorado  T  ON T.noControl    = B.noControl
      ORDER BY B.fechaRegistro DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { noControl, noEmpleado, idPrograma, motivoBaja, fechaUltimaSesion } = req.body;

    if (!noControl || !noEmpleado || !idPrograma || !motivoBaja)
      return res.status(400).json({ success: false, message: 'Debe seleccionar un motivo de baja para continuar' });

    const pool = await getPool();

    const existe = await pool.request()
      .input('nc', sql.NVarChar(20), noControl)
      .query(`SELECT 1 FROM Tutorado WHERE noControl = @nc`);
    if (!existe.recordset[0])
      return res.status(404).json({ success: false, message: 'No se encontró el alumno con ese número de control' });

    await pool.request()
      .input('noControl',        sql.NVarChar(20), noControl)
      .input('noEmpleado',       sql.NVarChar(20), noEmpleado)
      .input('idPrograma',       sql.Int,           idPrograma)
      .input('motivoBaja',       sql.NVarChar(30),  motivoBaja)
      .input('fechaUltimaSesion',sql.Date,          fechaUltimaSesion || null)
      .input('registradoPor',    sql.Int,           req.usuario.idUsuario)
      .execute('sp_RegistrarBaja');

    return res.status(201).json({ success: true, message: 'Baja registrada. Cupo liberado correctamente.' });
  } catch (err) { next(err); }
};

module.exports = { getAll, create };
