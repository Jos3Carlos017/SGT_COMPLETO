const bcrypt = require('bcryptjs');
const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT T.noEmpleado, U.nombre, U.correoInst, U.estado,
             T.tipoContrato, T.diplomado, T.cupoDisponible,
             25 - T.cupoDisponible AS tutoradosAsignados
      FROM Tutor T INNER JOIN Usuario U ON T.idUsuario = U.idUsuario
      ORDER BY U.nombre`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getOne = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('emp', sql.VarChar(20), req.params.noEmpleado)
      .query(`SELECT T.noEmpleado, U.nombre, U.correoInst, U.estado,
                     T.tipoContrato, T.diplomado, T.cupoDisponible
              FROM Tutor T INNER JOIN Usuario U ON T.idUsuario = U.idUsuario
              WHERE T.noEmpleado = @emp`);
    if (!result.recordset[0]) return res.status(404).json({ success: false, message: 'Tutor no encontrado' });
    return res.status(200).json({ success: true, data: result.recordset[0] });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { nombre, correoInst, noEmpleado, tipoContrato, diplomado, idJefeDepto, password } = req.body;
    const pool = await getPool();

    // Crear tutor via SP (siempre pone CAMBIAR_AL_PRIMER_LOGIN)
    await pool.request()
      .input('nombre',      sql.NVarChar(150), nombre)
      .input('correoInst',  sql.NVarChar(150), correoInst)
      .input('noEmpleado',  sql.NVarChar(20),  noEmpleado)
      .input('tipoContrato',sql.NVarChar(50),  tipoContrato || 'Tiempo Completo')
      .input('diplomado',   sql.Bit,           diplomado ? 1 : 0)
      .input('idJefeDepto', sql.Int,           idJefeDepto || null)
      .execute('sp_CrearTutor');

    // Si se proporcionó contraseña, hashearla y guardarla directamente
    if (password && password.length >= 6) {
      const hash = await bcrypt.hash(password, 10);
      await pool.request()
        .input('hash',      sql.NVarChar(255), hash)
        .input('noEmp',     sql.NVarChar(20),  noEmpleado)
        .query(`UPDATE Usuario SET passwordHash = @hash
                WHERE numEmpleado = @noEmp`);
    }

    return res.status(201).json({ success: true, message: 'Tutor creado correctamente' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { diplomado, cupoDisponible } = req.body;

    // Validación amigable: el tutor debe tener diplomado
    if (diplomado === false || diplomado === 0 || diplomado === '0') {
      return res.status(400).json({
        success: false,
        message: 'El tutor debe contar con el diplomado para poder participar en el programa de tutorías.',
      });
    }

    const pool = await getPool();
    await pool.request()
      .input('emp',  sql.VarChar(20), req.params.noEmpleado)
      .input('dipl', sql.Bit,         1)
      // Si no se envía cupoDisponible, mantener el valor actual con COALESCE
      .input('cupo', sql.SmallInt,    cupoDisponible ?? null)
      .query(`UPDATE Tutor
              SET diplomado       = @dipl,
                  cupoDisponible  = COALESCE(@cupo, cupoDisponible)
              WHERE noEmpleado = @emp`);
    return res.status(200).json({ success: true, message: 'Tutor actualizado' });
  } catch (err) { next(err); }
};

const desactivar = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('emp', sql.VarChar(20), req.params.noEmpleado)
      .query(`UPDATE U SET U.estado='Inactivo'
              FROM Usuario U INNER JOIN Tutor T ON T.idUsuario=U.idUsuario
              WHERE T.noEmpleado=@emp`);
    return res.status(200).json({ success: true, message: 'Tutor desactivado' });
  } catch (err) { next(err); }
};

module.exports = { getAll, getOne, create, update, desactivar };
