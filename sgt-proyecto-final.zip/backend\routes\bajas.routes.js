const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/bajas.controller');

router.get('/',  auth, ctrl.getAll);
router.post('/', auth, ctrl.create);

module.exports = router;
