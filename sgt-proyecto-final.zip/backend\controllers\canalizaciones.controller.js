const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT C.idCanalizacion, C.tipoAtencion, C.motivo, C.fechaCanalizacion,
             C.estatus, C.observaciones,
             C.noControl, UE.nombre AS tutorado,
             C.noEmpleado, UT.nombre AS tutor,
             C.idPrograma, P.cicloEscolar
      FROM Canalizacion C
      INNER JOIN Tutorado  T  ON T.noControl   = C.noControl
      INNER JOIN Usuario   UE ON UE.idUsuario  = T.idUsuario
      INNER JOIN Tutor     TU ON TU.noEmpleado = C.noEmpleado
      INNER JOIN Usuario   UT ON UT.idUsuario  = TU.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = C.idPrograma
      ORDER BY C.fechaCanalizacion DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { tipoAtencion, motivo, noControl, noEmpleado, idPrograma, observaciones } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('tipo',         sql.NVarChar(20),      tipoAtencion)
      .input('motivo',       sql.NVarChar(sql.MAX),  motivo)
      .input('noControl',    sql.NVarChar(20),       noControl)
      .input('noEmpleado',   sql.NVarChar(20),       noEmpleado)
      .input('idPrograma',   sql.Int,                idPrograma)
      .input('observaciones',sql.NVarChar(sql.MAX),  observaciones || null)
      .query(`INSERT INTO Canalizacion(tipoAtencion,motivo,noControl,noEmpleado,idPrograma,observaciones)
              VALUES(@tipo,@motivo,@noControl,@noEmpleado,@idPrograma,@observaciones)`);
    return res.status(201).json({ success: true, message: 'Canalización registrada' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { estatus, observaciones } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('id',           sql.Int,               req.params.id)
      .input('estatus',      sql.NVarChar(20),       estatus)
      .input('observaciones',sql.NVarChar(sql.MAX),  observaciones || null)
      .query(`UPDATE Canalizacion SET estatus=@estatus, observaciones=@observaciones
              WHERE idCanalizacion=@id`);
    return res.status(200).json({ success: true, message: 'Canalización actualizada' });
  } catch (err) { next(err); }
};

const remove = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`DELETE FROM Canalizacion WHERE idCanalizacion=@id`);
    return res.status(200).json({ success: true, message: 'Canalización eliminada' });
  } catch (err) { next(err); }
};

module.exports = { getAll, create, update, remove };
