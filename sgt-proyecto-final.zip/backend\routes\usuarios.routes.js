const router  = require('express').Router();
const auth    = require('../middlewares/auth');
const ctrl    = require('../controllers/usuarios.controller');

router.get('/',                auth, ctrl.getAll);
router.post('/',               auth, ctrl.create);
router.put('/:id',             auth, ctrl.update);
router.delete('/:id',          auth, ctrl.desactivar);
router.patch('/:id/desactivar',auth, ctrl.desactivar);
router.patch('/:id/reset',     auth, ctrl.resetPassword);

module.exports = router;
