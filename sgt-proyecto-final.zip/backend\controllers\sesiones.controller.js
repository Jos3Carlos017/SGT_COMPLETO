/**
 * Controlador de sesiones (RF-SES-01)
 * CORRECCIÓN 3: Si el tutor no asistió a su propia sesión, se registra falta.
 * CORRECCIÓN 4: La fecha de finalización para subir trabajos debe ser <= fecha actual.
 * @module controllers/sesiones
 */
const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT S.idSesion, S.numSesion, S.fecha, S.hora, S.aula,
             S.descripcion, S.conEvidencia, S.noEmpleado,
             S.tutorAsistio, S.fechaLimiteEntrega,
             U.nombre AS tutor, P.cicloEscolar
      FROM   Sesion S
      INNER JOIN Tutor T ON T.noEmpleado = S.noEmpleado
      INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
      INNER JOIN Programa_Tutorias P ON P.idPrograma = S.idPrograma
      ORDER BY S.fecha DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getByTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noEmp', sql.VarChar(20), req.params.noEmp)
      .query(`SELECT idSesion, numSesion, fecha, hora, aula, descripcion,
                     conEvidencia, tutorAsistio, fechaLimiteEntrega, idPrograma
              FROM   Sesion WHERE noEmpleado = @noEmp ORDER BY numSesion`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getById = async (req, res, next) => {
  try {
    const pool    = await getPool();
    const sesion  = await pool.request().input('id', sql.Int, req.params.id)
      .query(`SELECT S.*, U.nombre AS tutor FROM Sesion S
              INNER JOIN Tutor T ON T.noEmpleado = S.noEmpleado
              INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
              WHERE S.idSesion = @id`);
    if (!sesion.recordset[0])
      return res.status(404).json({ success: false, message: 'Sesión no encontrada.' });
    const asistencias = await pool.request().input('id', sql.Int, req.params.id)
      .query(`SELECT A.noControl, U.nombre, A.asistio,
                     ISNULL(A.justificado, 0) AS justificado
              FROM Asistencia A
              INNER JOIN Tutorado T ON T.noControl = A.noControl
              INNER JOIN Usuario U ON U.idUsuario = T.idUsuario
              WHERE A.idSesion = @id`);
    return res.status(200).json({
      success: true,
      data: { ...sesion.recordset[0], asistencias: asistencias.recordset },
    });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// TUTORADO: sus sesiones con estado de asistencia (actividad, aula, hora, fecha)
// ─────────────────────────────────────────────────────────────────────────────
const getByTutorado = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noControl', sql.VarChar(20), req.params.noControl)
      .query(`
        SELECT DISTINCT
          S.idSesion,
          S.numSesion,
          S.fecha,
          COALESCE(S.hora, GT.horaInicio) AS hora,
          COALESCE(S.aula, GT.salon)      AS aula,
          GT.dia,
          ISNULL(S.descripcion, 'Sin actividad') AS actividad,
          CASE
            WHEN AS2.asistio = 1               THEN 'asistio'
            WHEN ISNULL(AS2.justificado,0) = 1 THEN 'justificado'
            WHEN AS2.idAsistencia IS NOT NULL   THEN 'inasistencia'
            ELSE                                    'sinregistro'
          END AS estadoAsistencia,
          P.cicloEscolar,
          UT.nombre AS tutor
        FROM   Asignacion A
        INNER JOIN Sesion S            ON S.noEmpleado = A.noEmpleado AND S.idPrograma = A.idPrograma
        INNER JOIN Programa_Tutorias P ON P.idPrograma = S.idPrograma
        LEFT  JOIN Asistencia AS2      ON AS2.idSesion  = S.idSesion AND AS2.noControl = @noControl
        LEFT  JOIN GrupoTutor GT       ON GT.noEmpleado = A.noEmpleado AND GT.idPrograma = A.idPrograma AND GT.estado = 'Activo'
        LEFT  JOIN Tutor   TU          ON TU.noEmpleado = A.noEmpleado
        LEFT  JOIN Usuario UT          ON UT.idUsuario  = TU.idUsuario
        WHERE  A.noControl = @noControl AND A.estado = 'Activa'
        ORDER  BY S.numSesion
      `);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// PANEL ASISTENCIA: retorna TODOS los tutorados del tutor con su estado de asistencia
// ─────────────────────────────────────────────────────────────────────────────
const getAsistenciaBySesion = async (req, res, next) => {
  try {
    const idSesion = parseInt(req.params.idSesion);
    const noEmp    = req.params.noEmp;
    const pool     = await getPool();

    const sesionRes = await pool.request()
      .input('id', sql.Int, idSesion)
      .query(`SELECT idSesion, numSesion, fecha, noEmpleado, tutorAsistio
              FROM Sesion WHERE idSesion = @id`);
    if (!sesionRes.recordset[0])
      return res.status(404).json({ success: false, message: 'Sesión no encontrada.' });

    const empleado = noEmp || sesionRes.recordset[0].noEmpleado;

    const result = await pool.request()
      .input('noEmp',    sql.VarChar(20), empleado)
      .input('idSesion', sql.Int,         idSesion)
      .query(`
        SELECT
          A.noControl,
          U.nombre      AS tutorado,
          T.carrera,
          T.semestre,
          AS2.asistio,
          ISNULL(AS2.justificado, 0) AS justificado
        FROM Asignacion A
        INNER JOIN Tutorado T  ON T.noControl  = A.noControl
        INNER JOIN Usuario  U  ON U.idUsuario  = T.idUsuario
        LEFT  JOIN Asistencia AS2 ON AS2.idSesion = @idSesion AND AS2.noControl = A.noControl
        WHERE A.noEmpleado = @noEmp AND A.estado = 'Activa'
        ORDER BY U.nombre`);

    return res.status(200).json({
      success: true,
      data:   result.recordset,
      sesion: sesionRes.recordset[0],
    });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// CORRECCIÓN 4: Validar fechaLimiteEntrega <= fecha actual al crear sesión
// ─────────────────────────────────────────────────────────────────────────────
const create = async (req, res, next) => {
  try {
    const { numSesion, fecha, aula, descripcion, noEmpleado, idPrograma, fechaLimiteEntrega } = req.body;
    let hora = req.body.hora || null;
    if (hora && hora.length === 5) hora = hora + ':00';

    if (fechaLimiteEntrega) {
      const hoy    = new Date();
      hoy.setHours(0, 0, 0, 0);
      const minimo = new Date(hoy);
      minimo.setDate(minimo.getDate() + 7);   // mínimo 1 semana desde hoy
      const limite = new Date(fechaLimiteEntrega);
      if (limite < minimo) {
        return res.status(400).json({
          success: false,
          message: 'La fecha límite de entrega debe ser al menos 7 días a partir de hoy.',
        });
      }
    }

    const pool   = await getPool();
    const result = await pool.request()
      .input('numSesion',         sql.SmallInt,          numSesion)
      .input('fecha',             sql.Date,              fecha)
      .input('hora',              sql.NVarChar(10),      hora               || null)
      .input('aula',              sql.VarChar(50),       aula               || null)
      .input('descripcion',       sql.NVarChar(sql.MAX), descripcion        || null)
      .input('noEmpleado',        sql.VarChar(20),       noEmpleado)
      .input('idPrograma',        sql.Int,               idPrograma)
      .input('fechaLimiteEntrega',sql.Date,              fechaLimiteEntrega || null)
      .query(`INSERT INTO Sesion (numSesion, fecha, hora, aula, descripcion, noEmpleado, idPrograma, fechaLimiteEntrega)
              OUTPUT INSERTED.idSesion
              VALUES (@numSesion,@fecha,@hora,@aula,@descripcion,@noEmpleado,@idPrograma,@fechaLimiteEntrega)`);

    return res.status(201).json({
      success: true,
      message: 'Sesión registrada. Recuerde adjuntar la evidencia.',
      data: { idSesion: result.recordset[0].idSesion },
    });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { fecha, aula, descripcion, fechaLimiteEntrega } = req.body;
    let hora = req.body.hora || null;
    if (hora && hora.length === 5) hora = hora + ':00';

    if (fechaLimiteEntrega) {
      const hoy    = new Date();
      hoy.setHours(0, 0, 0, 0);
      const minimo = new Date(hoy);
      minimo.setDate(minimo.getDate() + 7);
      const limite = new Date(fechaLimiteEntrega);
      if (limite < minimo) {
        return res.status(400).json({
          success: false,
          message: 'La fecha límite de entrega debe ser al menos 7 días a partir de hoy.',
        });
      }
    }

    const pool  = await getPool();
    const check = await pool.request().input('id', sql.Int, req.params.id)
      .query('SELECT idSesion FROM Sesion WHERE idSesion = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Sesión no encontrada.' });

    await pool.request()
      .input('id',               sql.Int,              req.params.id)
      .input('fecha',            sql.Date,             fecha              || null)
      .input('hora',             sql.NVarChar(10),     hora               || null)
      .input('aula',             sql.VarChar(50),      aula               || null)
      .input('descripcion',      sql.NVarChar(sql.MAX), descripcion       || null)
      .input('fechaLimiteEntrega',sql.Date,            fechaLimiteEntrega || null)
      .query(`UPDATE Sesion SET
                fecha             = COALESCE(@fecha,             fecha),
                hora              = COALESCE(@hora,              hora),
                aula              = COALESCE(@aula,              aula),
                descripcion       = COALESCE(@descripcion,       descripcion),
                fechaLimiteEntrega= COALESCE(@fechaLimiteEntrega,fechaLimiteEntrega)
              WHERE idSesion = @id`);
    return res.status(200).json({ success: true, message: 'Sesión actualizada.' });
  } catch (err) { next(err); }
};

// ─────────────────────────────────────────────────────────────────────────────
// Registrar asistencia con soporte para 3 estados: asistió / falta / justificado
// ─────────────────────────────────────────────────────────────────────────────
const registrarAsistencia = async (req, res, next) => {
  try {
    const { asistencias, tutorAsistio } = req.body;
    const idSesion = parseInt(req.params.id);
    const pool = await getPool();

    const check = await pool.request().input('id', sql.Int, idSesion)
      .query('SELECT idSesion, noEmpleado FROM Sesion WHERE idSesion = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Sesión no encontrada.' });

    const asistioTutor = tutorAsistio === true || tutorAsistio === 1;
    await pool.request()
      .input('id',           sql.Int, idSesion)
      .input('tutorAsistio', sql.Bit, asistioTutor ? 1 : 0)
      .query(`UPDATE Sesion SET tutorAsistio = @tutorAsistio WHERE idSesion = @id`);

    if (!asistioTutor) {
      await pool.request()
        .input('noEmpleado', sql.VarChar(20), check.recordset[0].noEmpleado)
        .input('idSesion',   sql.Int,         idSesion)
        .query(`
          IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'FaltaTutor')
          BEGIN
            MERGE FaltaTutor AS target
            USING (SELECT @idSesion AS idSesion, @noEmpleado AS noEmpleado) AS src
              ON target.idSesion = src.idSesion AND target.noEmpleado = src.noEmpleado
            WHEN NOT MATCHED THEN
              INSERT (noEmpleado, idSesion, fechaRegistro)
              VALUES (@noEmpleado, @idSesion, GETDATE());
          END
        `);
    }

    // Registrar asistencia de tutorados (con soporte para justificado si existe la columna)
    for (const a of asistencias) {
      const asistio     = a.asistio     ? 1 : 0;
      const justificado = a.justificado ? 1 : 0;
      try {
        await pool.request()
          .input('idSesion',    sql.Int,        idSesion)
          .input('noControl',   sql.VarChar(20), a.noControl)
          .input('asistio',     sql.Bit,         asistio)
          .input('justificado', sql.Bit,         justificado)
          .query(`MERGE Asistencia AS target
                  USING (SELECT @idSesion AS idSesion, @noControl AS noControl) AS src
                    ON target.idSesion=src.idSesion AND target.noControl=src.noControl
                  WHEN MATCHED THEN UPDATE SET asistio=@asistio, justificado=@justificado
                  WHEN NOT MATCHED THEN INSERT (idSesion,noControl,asistio,justificado)
                    VALUES (@idSesion,@noControl,@asistio,@justificado);`);
      } catch {
        // Fallback si columna justificado no existe aún (antes de migración v4)
        await pool.request()
          .input('idSesion',  sql.Int,        idSesion)
          .input('noControl', sql.VarChar(20), a.noControl)
          .input('asistio',   sql.Bit,         asistio)
          .query(`MERGE Asistencia AS target
                  USING (SELECT @idSesion AS idSesion, @noControl AS noControl) AS src
                    ON target.idSesion=src.idSesion AND target.noControl=src.noControl
                  WHEN MATCHED THEN UPDATE SET asistio=@asistio
                  WHEN NOT MATCHED THEN INSERT (idSesion,noControl,asistio)
                    VALUES (@idSesion,@noControl,@asistio);`);
      }
    }

    const mensajeTutor = asistioTutor
      ? ''
      : ' Se ha registrado FALTA al tutor por no asistir a la sesión.';

    return res.status(200).json({
      success: true,
      message: `Asistencia registrada para ${asistencias.length} tutorado(s).${mensajeTutor}`,
      tutorAsistio: asistioTutor,
    });
  } catch (err) { next(err); }
};

// Encuentra o crea una Sesion vinculada a una Actividad (para el panel de asistencia)
const getOrCreateFromActividad = async (req, res, next) => {
  try {
    const { idActividad, noEmpleado, idPrograma } = req.body;
    const pool = await getPool();

    // Info de la actividad
    const actRes = await pool.request()
      .input('id', sql.Int, idActividad)
      .query('SELECT titulo, idPrograma FROM Actividad WHERE idActividad=@id');
    if (!actRes.recordset[0])
      return res.status(404).json({ success:false, message:'Actividad no encontrada' });
    const act   = actRes.recordset[0];
    const progId = idPrograma || act.idPrograma;

    // Buscar sesión existente por descripción (título de actividad)
    const existing = await pool.request()
      .input('noEmp', sql.NVarChar(20), noEmpleado)
      .input('prog',  sql.Int,          progId)
      .input('desc',  sql.NVarChar(500), act.titulo)
      .query(`SELECT TOP 1 idSesion FROM Sesion
              WHERE noEmpleado=@noEmp AND idPrograma=@prog
              AND descripcion LIKE @desc+'%'
              ORDER BY idSesion`);
    if (existing.recordset[0])
      return res.status(200).json({ success:true, data:{ idSesion: existing.recordset[0].idSesion } });

    // Usar el índice de la actividad como numSesion (S1=1, S2=2…) — máx 8
    const actIndex  = req.body.actIndex ? parseInt(req.body.actIndex) : null;
    const numSesion = actIndex ? Math.min(actIndex, 8) : (() => {
      // Fallback: siguiente disponible
      return null; // se calculará abajo
    })();

    // Si viene índice, intentar encontrar sesión por ese numSesion
    if (numSesion) {
      const byNum = await pool.request()
        .input('noEmp', sql.NVarChar(20), noEmpleado)
        .input('prog',  sql.Int,          progId)
        .input('num',   sql.SmallInt,     numSesion)
        .query('SELECT TOP 1 idSesion FROM Sesion WHERE noEmpleado=@noEmp AND idPrograma=@prog AND numSesion=@num');
      if (byNum.recordset[0])
        return res.status(200).json({ success:true, data:{ idSesion: byNum.recordset[0].idSesion } });
    }

    // Calcular siguiente numSesion si no viene índice
    const numRes = await pool.request()
      .input('noEmp', sql.NVarChar(20), noEmpleado)
      .input('prog',  sql.Int,          progId)
      .query('SELECT ISNULL(MAX(numSesion),0)+1 AS sig FROM Sesion WHERE noEmpleado=@noEmp AND idPrograma=@prog');
    const finalNum = numSesion || numRes.recordset[0].sig;
    if (finalNum > 8) {
      // Reutilizar la sesión 8 si existe
      const last = await pool.request()
        .input('noEmp', sql.NVarChar(20), noEmpleado)
        .input('prog',  sql.Int,          progId)
        .query('SELECT TOP 1 idSesion FROM Sesion WHERE noEmpleado=@noEmp AND idPrograma=@prog ORDER BY numSesion DESC');
      if (last.recordset[0])
        return res.status(200).json({ success:true, data:{ idSesion: last.recordset[0].idSesion } });
      return res.status(400).json({ success:false, message:'No hay sesiones disponibles.' });
    }

    // Hora/Aula del grupo
    const grupoRes = await pool.request()
      .input('noEmp', sql.NVarChar(20), noEmpleado)
      .input('prog',  sql.Int,          progId)
      .query(`SELECT salon, horaInicio FROM GrupoTutor
              WHERE noEmpleado=@noEmp AND idPrograma=@prog AND estado='Activo'`);
    const grupo = grupoRes.recordset[0] || null;

    // Fecha límite = hoy + 7 días
    const limite = new Date(); limite.setDate(limite.getDate()+7);
    const limStr = limite.toISOString().split('T')[0];

    const insertRes = await pool.request()
      .input('num',   sql.SmallInt,          finalNum)
      .input('fecha', sql.Date,              new Date().toISOString().split('T')[0])
      .input('hora',  sql.NVarChar(10),      grupo?.horaInicio || null)
      .input('aula',  sql.NVarChar(50),      grupo?.salon      || null)
      .input('desc',  sql.NVarChar(sql.MAX), act.titulo)
      .input('noEmp', sql.NVarChar(20),      noEmpleado)
      .input('prog',  sql.Int,               progId)
      .input('lim',   sql.Date,              limStr)
      .query(`INSERT INTO Sesion(numSesion,fecha,hora,aula,descripcion,noEmpleado,idPrograma,fechaLimiteEntrega)
              OUTPUT INSERTED.idSesion
              VALUES(@num,@fecha,@hora,@aula,@desc,@noEmp,@prog,@lim)`);

    return res.status(201).json({ success:true, data:{ idSesion: insertRes.recordset[0].idSesion } });
  } catch (err) { next(err); }
};

module.exports = { getAll, getByTutor, getByTutorado, getById, getAsistenciaBySesion, getOrCreateFromActividad, create, update, registrarAsistencia };
