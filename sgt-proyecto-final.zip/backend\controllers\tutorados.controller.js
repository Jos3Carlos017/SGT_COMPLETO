const { getPool, sql } = require('../config/db');

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT T.noControl, U.nombre, U.correoInst, T.carrera, T.semestre, T.estatus
      FROM Tutorado T INNER JOIN Usuario U ON T.idUsuario = U.idUsuario
      ORDER BY U.nombre`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const getOne = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('nc', sql.VarChar(20), req.params.noControl)
      .query(`SELECT T.noControl, U.nombre, U.correoInst, T.carrera, T.semestre, T.estatus
              FROM Tutorado T INNER JOIN Usuario U ON T.idUsuario = U.idUsuario
              WHERE T.noControl = @nc`);
    if (!result.recordset[0]) return res.status(404).json({ success: false, message: 'Tutorado no encontrado' });
    return res.status(200).json({ success: true, data: result.recordset[0] });
  } catch (err) { next(err); }
};

const create = async (req, res, next) => {
  try {
    const { nombre, correoInst, noControl, carrera, semestre } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('nombre',    sql.NVarChar(150), nombre)
      .input('correoInst',sql.NVarChar(150), correoInst)
      .input('noControl', sql.NVarChar(20),  noControl)
      .input('carrera',   sql.NVarChar(100), carrera)
      .input('semestre',  sql.Int,           semestre)
      .execute('sp_CrearTutorado');
    return res.status(201).json({ success: true, message: 'Tutorado creado correctamente' });
  } catch (err) { next(err); }
};

const update = async (req, res, next) => {
  try {
    const { carrera, semestre } = req.body;
    const pool = await getPool();
    await pool.request()
      .input('nc',       sql.VarChar(20),  req.params.noControl)
      .input('carrera',  sql.NVarChar(100), carrera)
      .input('semestre', sql.SmallInt,      semestre)
      .query(`UPDATE Tutorado SET carrera=@carrera, semestre=@semestre WHERE noControl=@nc`);
    return res.status(200).json({ success: true, message: 'Tutorado actualizado' });
  } catch (err) { next(err); }
};

module.exports = { getAll, getOne, create, update };
