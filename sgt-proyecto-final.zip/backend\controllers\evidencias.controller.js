const path = require('path');
const fs   = require('fs');
const { getPool, sql } = require('../config/db');

const TIPOS_VALIDOS = ['Lista Asistencia', 'Actividad', 'Reporte', 'Canalizacion', 'Otro'];

const getAll = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request().query(`
      SELECT E.idEvidencia, E.tipoEvidencia, E.nombreArchivo, E.rutaArchivo,
             E.descripcion, E.fechaCarga, E.estado,
             E.calificacion, E.observaciones,
             E.idSesion, E.noControl, U.nombre AS cargadoPorNombre
      FROM Evidencia E
      INNER JOIN Usuario U ON U.idUsuario = E.cargadoPor
      WHERE E.estado = 'Activa'
      ORDER BY E.fechaCarga DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// Evidencias filtradas para tutorados de un tutor (para que el tutor las evalúe)
const getByTutor = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noEmp', sql.VarChar(20), req.params.noEmp)
      .query(`
        SELECT E.idEvidencia, E.tipoEvidencia, E.nombreArchivo, E.rutaArchivo,
               E.descripcion, E.fechaCarga, E.estado,
               E.calificacion, E.observaciones,
               E.idSesion, E.noControl,
               U.nombre  AS tutorado,
               S.numSesion,
               UC.nombre AS cargadoPorNombre
        FROM   Evidencia E
        INNER JOIN Tutorado T  ON T.noControl  = E.noControl
        INNER JOIN Usuario  U  ON U.idUsuario  = T.idUsuario
        INNER JOIN Usuario  UC ON UC.idUsuario = E.cargadoPor
        INNER JOIN Asignacion A ON A.noControl = E.noControl AND A.noEmpleado = @noEmp AND A.estado='Activa'
        LEFT  JOIN Sesion   S  ON S.idSesion   = E.idSesion
        WHERE  E.estado = 'Activa'
        ORDER  BY E.fechaCarga DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

// Evidencias de un tutorado (el tutorado ve sus propias evidencias con retroalimentación)
const getByTutorado = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('noControl', sql.VarChar(20), req.params.noControl)
      .query(`
        SELECT E.idEvidencia, E.tipoEvidencia, E.nombreArchivo,
               E.descripcion, E.fechaCarga, E.estado,
               E.calificacion, E.observaciones,
               E.idSesion, S.numSesion,
               U.nombre AS cargadoPorNombre
        FROM   Evidencia E
        INNER JOIN Usuario U ON U.idUsuario = E.cargadoPor
        LEFT  JOIN Sesion  S ON S.idSesion  = E.idSesion
        WHERE  E.noControl = @noControl AND E.estado = 'Activa'
        ORDER  BY E.fechaCarga DESC`);
    return res.status(200).json({ success: true, data: result.recordset });
  } catch (err) { next(err); }
};

const upload = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'Archivo PDF requerido' });

    const cargadoPor = req.usuario?.idUsuario;
    if (!cargadoPor)
      return res.status(401).json({ success: false, message: 'No se pudo identificar al usuario. Vuelve a iniciar sesión.' });

    const { descripcion, idSesion, noControl } = req.body;
    let tipoEvidencia = req.body.tipoEvidencia || 'Otro';
    if (!TIPOS_VALIDOS.includes(tipoEvidencia)) tipoEvidencia = 'Otro';

    const rutaArchivo = req.file.path;
    const pool = await getPool();
    await pool.request()
      .input('tipo',        sql.NVarChar(30),  tipoEvidencia)
      .input('tipoArch',    sql.NVarChar(10),  'pdf')
      .input('nombre',      sql.NVarChar(255), req.file.originalname)
      .input('ruta',        sql.NVarChar(500), rutaArchivo)
      .input('descripcion', sql.NVarChar(sql.MAX), descripcion || null)
      .input('idSesion',    sql.Int,           idSesion   ? parseInt(idSesion)  : null)
      .input('noControl',   sql.NVarChar(20),  noControl  || null)
      .input('cargadoPor',  sql.Int,           cargadoPor)
      .query(`INSERT INTO Evidencia(tipoEvidencia,tipoArchivo,nombreArchivo,rutaArchivo,descripcion,idSesion,noControl,cargadoPor)
              VALUES(@tipo,@tipoArch,@nombre,@ruta,@descripcion,@idSesion,@noControl,@cargadoPor)`);
    return res.status(201).json({ success: true, message: 'Evidencia subida correctamente' });
  } catch (err) { next(err); }
};

const archivar = async (req, res, next) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`UPDATE Evidencia SET estado='Archivada' WHERE idEvidencia = @id`);
    return res.status(200).json({ success: true, message: 'Evidencia archivada' });
  } catch (err) { next(err); }
};

// Descargar archivo PDF de una evidencia
const download = async (req, res, next) => {
  try {
    const pool   = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query('SELECT rutaArchivo, nombreArchivo FROM Evidencia WHERE idEvidencia = @id');
    if (!result.recordset[0])
      return res.status(404).json({ success: false, message: 'Evidencia no encontrada' });

    const { rutaArchivo, nombreArchivo } = result.recordset[0];
    if (!fs.existsSync(rutaArchivo))
      return res.status(404).json({ success: false, message: 'Archivo no encontrado en el servidor' });

    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(nombreArchivo)}"`);
    res.setHeader('Content-Type', 'application/pdf');
    fs.createReadStream(rutaArchivo).pipe(res);
  } catch (err) { next(err); }
};

// Evaluar una evidencia (tutor asigna calificación 1-4 y retroalimentación)
const evaluar = async (req, res, next) => {
  try {
    const { calificacion, observaciones, resultado } = req.body;
    const pool = await getPool();

    const check = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query('SELECT idEvidencia FROM Evidencia WHERE idEvidencia = @id');
    if (!check.recordset[0])
      return res.status(404).json({ success: false, message: 'Evidencia no encontrada' });

    // calificacion guarda el resultado (Aceptada/Corrección/Rechazada) + nivel (1-4)
    const calVal = resultado ? `${resultado}${calificacion ? ' - ' + calificacion : ''}` : (calificacion || null);

    await pool.request()
      .input('id',  sql.Int,          req.params.id)
      .input('cal', sql.NVarChar(30), calVal)
      .input('obs', sql.NVarChar(500), observaciones || null)
      .query(`UPDATE Evidencia SET calificacion=@cal, observaciones=@obs WHERE idEvidencia=@id`);

    return res.status(200).json({ success: true, message: 'Evaluación guardada correctamente' });
  } catch (err) { next(err); }
};

module.exports = { getAll, getByTutor, getByTutorado, upload, archivar, download, evaluar };
