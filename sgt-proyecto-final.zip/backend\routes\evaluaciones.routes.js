const router = require('express').Router();
const auth   = require('../middlewares/auth');
const ctrl   = require('../controllers/evaluaciones.controller');

router.get('/',              auth, ctrl.getAll);
router.get('/:id/criterios', auth, ctrl.getCriterios);
router.post('/',             auth, ctrl.create);
router.patch('/:id/validar', auth, ctrl.validar);

module.exports = router;
