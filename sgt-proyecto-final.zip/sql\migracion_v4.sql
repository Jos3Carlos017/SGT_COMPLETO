-- ═══════════════════════════════════════════════════════════════════════════
-- MIGRACIÓN V4 — SGT Correcciones adicionales
-- Ejecutar UNA SOLA VEZ en SSMS sobre la base SISTEMA_TUTORIAS existente.
-- ═══════════════════════════════════════════════════════════════════════════

USE SISTEMA_TUTORIAS;
GO

-- ─────────────────────────────────────────────────────────────────────────────
-- Agregar columna justificado a Asistencia (para 3 estados: asistió / falta / justificado)
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'Asistencia' AND COLUMN_NAME = 'justificado'
)
BEGIN
  ALTER TABLE Asistencia ADD justificado BIT NOT NULL DEFAULT 0;
  PRINT 'Columna justificado agregada a Asistencia.';
END
ELSE PRINT 'Columna justificado ya existe en Asistencia.';
GO

-- ─────────────────────────────────────────────────────────────────────────────
-- Verificar que Evidencia ya tiene calificacion y observaciones (v3 las incluye)
-- ─────────────────────────────────────────────────────────────────────────────
IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'Evidencia' AND COLUMN_NAME = 'calificacion'
)
BEGIN
  ALTER TABLE Evidencia ADD calificacion NVARCHAR(30) NULL;
  PRINT 'Columna calificacion agregada a Evidencia.';
END
ELSE PRINT 'Columna calificacion ya existe en Evidencia.';
GO

IF NOT EXISTS (
  SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = 'Evidencia' AND COLUMN_NAME = 'observaciones'
)
BEGIN
  ALTER TABLE Evidencia ADD observaciones NVARCHAR(500) NULL;
  PRINT 'Columna observaciones agregada a Evidencia.';
END
ELSE PRINT 'Columna observaciones ya existe en Evidencia.';
GO

SELECT 'Migración V4 completada correctamente.' AS Resultado;
GO
